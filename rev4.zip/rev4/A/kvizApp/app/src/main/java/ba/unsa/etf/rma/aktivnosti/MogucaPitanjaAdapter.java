package ba.unsa.etf.rma.aktivnosti;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Pitanje;

import static ba.unsa.etf.rma.aktivnosti.KvizoviAkt.kvizovi;
import static ba.unsa.etf.rma.aktivnosti.KvizoviAkt.pitanja;

public class MogucaPitanjaAdapter extends ArrayAdapter<Pitanje> {

    int pitanje_item;

    public MogucaPitanjaAdapter (Context context, int resource, List<Pitanje> items){
        super(context, resource, items);
        pitanje_item = resource; // id layout-a list item-a
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent){
        // Kreiranje i inflate-anje view klase
        LinearLayout newView;

        if(convertView == null){
            // Za slučaj prvog pristupanja klasi, tj. nije update
            // Kreira se novi objekat i potrebno ga je inflate-ati

            newView = new LinearLayout(getContext());
            String inflater = Context.LAYOUT_INFLATER_SERVICE;
            LayoutInflater li;
            li = (LayoutInflater)getContext().getSystemService(inflater);
            li.inflate(pitanje_item, newView, true);
        }
        else{
            // Ukoliko je update, potrebno je samo izmijeniti vrijednosti polja

            newView = (LinearLayout)convertView;
        }
        Pitanje p = getItem(position);
        // Ovdje dohvaćamo referencu na View i popunjavamo vrijednostima polja iz objekta

        TextView nazivPitanja = (TextView) newView.findViewById(R.id.tv_tekst_moguceg);
        ImageView kategorijaPitanja = (ImageView) newView.findViewById(R.id.iv_slika_moguceg);
        
        nazivPitanja.setText(p.getNaziv());
        kategorijaPitanja.setImageResource(R.drawable.addmore);
        
        return newView;
    }
}
