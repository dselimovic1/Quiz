package ba.unsa.etf.rma.aktivnosti;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;

import static ba.unsa.etf.rma.aktivnosti.KvizoviAkt.kategorije;
import static ba.unsa.etf.rma.aktivnosti.KvizoviAkt.kvizovi;
import static ba.unsa.etf.rma.aktivnosti.KvizoviAkt.pitanja;
import static ba.unsa.etf.rma.aktivnosti.KvizoviAkt.pomKategorije;
import static ba.unsa.etf.rma.aktivnosti.KvizoviAkt.pomKvizovi;
import static ba.unsa.etf.rma.aktivnosti.KvizoviAkt.selektovanaKategorija;
import static ba.unsa.etf.rma.aktivnosti.KvizoviAkt.selektovaniKviz;

public class DodajKvizAkt extends AppCompatActivity {

    static Kviz k = new Kviz();
    static int promijenjeni;
    static int odabranaKategorija;
    static ArrayList<Pitanje> mogucaPitanja = new ArrayList<>();
    static ArrayList<Pitanje> dodanaPitanja = new ArrayList<>();

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dodaj_kviz);

        final Spinner spKategorije = (Spinner) findViewById(R.id.sp_kategorije);
        final EditText etNaziv = (EditText) findViewById(R.id.et_naziv_kviza);
        final Button btnDodajKviz = (Button) findViewById(R.id.b_dodaj_kviz);
        final ListView lvDodanaPitanja = (ListView) findViewById(R.id.lv_dodana_pitanja);
        ListView lvMogucaPitanja = (ListView) findViewById(R.id.lv_moguca_pitanja);

        // spiner adapter kao array adapter
        final ArrayAdapter<String> adapterSpinner = new ArrayAdapter<String>
                (this,android.R.layout.simple_spinner_item, pomKategorije);
        adapterSpinner.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spKategorije.setAdapter(adapterSpinner);
        // spiner adapter kao array adapter

        spKategorije.setSelection(selektovanaKategorija);

        getIntent();

        final String nazivKviza = getIntent().getStringExtra("naziv");

        dodanaPitanja.clear();
        mogucaPitanja.clear();
        if(nazivKviza == "Dodaj Kviz"){
            etNaziv.setText("Naziv kviza - INPUT");
            dodanaPitanja.add(new Pitanje("Dodaj Pitanje"));
            mogucaPitanja = new ArrayList<Pitanje>(pitanja);
        }
        else{
            k = new Kviz(pomKvizovi.get(selektovaniKviz));
            etNaziv.setText(nazivKviza);
            dodanaPitanja = k.getPitanja();
            dodanaPitanja.add(new Pitanje("Dodaj Pitanje"));
            for(int i = 0; i < pitanja.size(); ++i){
                for(int j = 0; j < dodanaPitanja.size(); ++j){
                    if(pitanja.get(i).getNaziv() != dodanaPitanja.get(j).getNaziv()){
                        mogucaPitanja.add(new Pitanje(pitanja.get(i)));
                    }
                }
            }
        }

        // dodaj kategoriju item na kraju spinner liste -> intent na aktivnost dodaj kategoriju

        final PitanjeAdapter dodanoPitanjeAdapter =
                new PitanjeAdapter(this, R.layout.element_liste_dodana, dodanaPitanja);
        lvDodanaPitanja.setAdapter(dodanoPitanjeAdapter);

        final MogucaPitanjaAdapter mogucePitanjeAdapter =
                new MogucaPitanjaAdapter(this, R.layout.element_liste_moguca, mogucaPitanja);
        lvMogucaPitanja.setAdapter(mogucePitanjeAdapter);

        lvDodanaPitanja.setAdapter(dodanoPitanjeAdapter);
        dodanoPitanjeAdapter.notifyDataSetChanged();
        lvMogucaPitanja.setAdapter(mogucePitanjeAdapter);
        mogucePitanjeAdapter.notifyDataSetChanged();

        spKategorije.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if(spKategorije.getSelectedItem().toString() == "Svi")
                    btnDodajKviz.setClickable(false);
                odabranaKategorija = position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        lvMogucaPitanja.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                dodanaPitanja.add(dodanaPitanja.size() - 1, mogucaPitanja.get(position));
                dodanaPitanja.add(new Pitanje("Dodaj Pitanje"));
                dodanoPitanjeAdapter.notifyDataSetChanged();
                mogucaPitanja.remove(mogucaPitanja.get(position));
                mogucePitanjeAdapter.notifyDataSetChanged();
            }
        });

        btnDodajKviz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(nazivKviza == etNaziv.getText().toString()){
                    for(int i = 0; i < kvizovi.size(); ++i){
                        if(nazivKviza == kvizovi.get(i).getNaziv()){
                            promijenjeni = i;
                        }
                    }
                    kvizovi.get(promijenjeni).getPitanja().clear();
                    kvizovi.get(promijenjeni).setPitanja(dodanaPitanja);
                    //kvizovi.get(promijenjeni).setKategorija(spKategorije.); ako je promijenjena kategorija
                }
                else{
                    dodanaPitanja.remove(dodanaPitanja.size() - 1);
                    kvizovi.add(new Kviz(etNaziv.getText().toString(), dodanaPitanja, kategorije.get(odabranaKategorija)));
                }
                finishActivity(1);
            }
        });

        lvDodanaPitanja.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if(dodanoPitanjeAdapter.getItem(position).getNaziv() == "Dodaj Pitanje"){
                    Intent myIntent = new Intent(DodajKvizAkt.this, DodajPitanjeAkt.class);

                    startActivityForResult(myIntent, 2);
                }
            }
        });
    }
}
