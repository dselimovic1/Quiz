package ba.unsa.etf.rma.aktivnosti;

import android.support.v4.app.Fragment;

public class InformacijeFrag extends Fragment {
}
