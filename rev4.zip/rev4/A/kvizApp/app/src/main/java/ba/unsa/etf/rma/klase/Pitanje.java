package ba.unsa.etf.rma.klase;

import android.widget.ArrayAdapter;

import java.io.Serializable;
import java.util.ArrayList;

public class Pitanje implements Serializable {
    private String naziv;
    private String tekstPitanja;
    private ArrayList<String> odgovori;
    private String tacan;

    public Pitanje(){}

    public Pitanje(String pitanje){
        setNaziv(pitanje);
    }

    public Pitanje(Pitanje p){
        setNaziv(p.getNaziv());
        setTekstPitanja(p.getTekstPitanja());
        setOdgovori(p.getOdgovori());
        setTacan(p.getTacan());
    }

    public Pitanje(String naziv, String tekstPitanja, ArrayList<String> odgovori, String tacan)
    {
        setNaziv(naziv);
        setTekstPitanja(tekstPitanja);
        setTacan(tacan);
        setOdgovori(odgovori);
    }

    ArrayList<String> dajRandomOdgovore(){ // vraca listu odgovora poredanu u slucajnom redoslijedu

        return odgovori;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public String getTekstPitanja() {
        return tekstPitanja;
    }

    public void setTekstPitanja(String tekstPitanja) {
        this.tekstPitanja = tekstPitanja;
    }

    public ArrayList<String> getOdgovori() {
        return odgovori;
    }

    public void setOdgovori(ArrayList<String> odgovori) {
        this.odgovori = odgovori;
    }

    public String getTacan() {
        return tacan;
    }

    public void setTacan(String tacan) {
        this.tacan = tacan;
    }
}
