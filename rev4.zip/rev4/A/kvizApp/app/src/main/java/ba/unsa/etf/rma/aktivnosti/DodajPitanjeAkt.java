package ba.unsa.etf.rma.aktivnosti;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Pitanje;

public class DodajPitanjeAkt extends AppCompatActivity {

    static Pitanje pitanje;
    static ArrayList<String> odgovori;

    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dodaj_pitanje);

        final EditText etNaziv = (EditText) findViewById(R.id.et_naziv_pitanja);
        final EditText etOdgovor = (EditText) findViewById(R.id.et_odgovor);
        ListView lvOdgovori = (ListView) findViewById(R.id.lv_odgovori);
        Button btnDodajOdgovor = (Button) findViewById(R.id.b_dodaj_odgovor);
        Button btnDodajTacan = (Button) findViewById(R.id.b_dodaj_tacan);
        Button btnDodajPitanje = (Button) findViewById(R.id.b_dodaj_pitanje);

        getIntent();

        final ArrayAdapter<String> adapterOdgovori =
                new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, odgovori);

        btnDodajOdgovor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                odgovori.add(etOdgovor.getText().toString());
                adapterOdgovori.notifyDataSetChanged();
            }
        });

        btnDodajTacan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                odgovori.add(etOdgovor.getText().toString());
                pitanje.setTacan(etOdgovor.getText().toString());
                adapterOdgovori.notifyDataSetChanged();
            }
        });

        btnDodajPitanje.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pitanje.setNaziv(etNaziv.getText().toString());
                pitanje.setOdgovori(odgovori);
                pitanje.setTekstPitanja(pitanje.getNaziv());
                finishActivity(2);
            }
        });
    }
}
