package ba.unsa.etf.rma.fragmenti;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Pitanje;


public class PitanjeFrag extends Fragment {
    private Pitanje pitanje;

    private TextView tekstPitanja;
    private ListView odgovorilv;
    private ArrayAdapter<String> odgovoriAdapter;
    private ArrayList<String> odgovori = new ArrayList<>();

    private OnItemClick onItemClick;

    private void promijeniBojuNaPoziciji(int position){
        if(odgovori.get(position).equals(pitanje.getTacan())){
            odgovorilv.getChildAt(position).setBackgroundColor(getResources().getColor(R.color.zelena));
        }
        else{
            odgovorilv.getChildAt(position).setBackgroundColor(getResources().getColor(R.color.crvena));
            for(int i = 0; i < odgovori.size(); i++)
                if (odgovori.get(i).equals(pitanje.getTacan())){
                    odgovorilv.getChildAt(i).setBackgroundColor(getResources().getColor(R.color.zelena));
                    break;
                }
        }

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.pitanje_frag, container, false);

        tekstPitanja = view.findViewById(R.id.tekstPitanja);
        odgovorilv = view.findViewById(R.id.odgovoriPitanja);
        return view;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        pitanje = (Pitanje) getArguments().getSerializable("pitanje");
        odgovori = getArguments().getStringArrayList("odgovori");
        if(pitanje != null) tekstPitanja.setText(pitanje.getNaziv());

        odgovoriAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_list_item_1, odgovori);
        odgovorilv.setAdapter(odgovoriAdapter);


        onItemClick = (OnItemClick) getActivity();

        odgovorilv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, final int position, long id) {
                promijeniBojuNaPoziciji(position);
                onItemClick.onItemClicked(position);
            }
        });


    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public interface OnItemClick {
        void onItemClicked(int pos);
    }

}
