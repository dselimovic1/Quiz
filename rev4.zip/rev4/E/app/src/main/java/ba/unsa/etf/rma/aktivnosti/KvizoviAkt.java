package ba.unsa.etf.rma.aktivnosti;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

import ba.unsa.etf.rma.utility.CalendarContentResolver;
import ba.unsa.etf.rma.utility.IBaza;
import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.adapteri.kategorija.KategorijaAdapterSpinner;
import ba.unsa.etf.rma.adapteri.kviz.KvizAdapterLista;
import ba.unsa.etf.rma.fragmenti.DetailFrag;
import ba.unsa.etf.rma.fragmenti.ListaFrag;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;
import ba.unsa.etf.rma.utility.KvizoviDBOpenHelper;
import ba.unsa.etf.rma.utility.Mreza;

public class KvizoviAkt extends AppCompatActivity implements ListaFrag.OnItemClick, DetailFrag.onItemClick {
    private ListView listaKvizovi;
    private Spinner spinnerKategorije;
    private KvizAdapterLista kvizAdapter;
    private KategorijaAdapterSpinner kategorijaAdapter;

    private ArrayList<Kviz> sviKvizovi = new ArrayList<>();
    private ArrayList<Kviz> kvizoviUKategoriji = new ArrayList<>();
    private ArrayList<Kategorija> kategorije = new ArrayList<>();
    private ArrayList<Pitanje> pitanja = new ArrayList<>();

    private FragmentManager fragmentManager;
    private FrameLayout detailPlace;
    private FrameLayout listPlace;

    private ListaFrag listaFrag;
    private DetailFrag detailFrag;

    private boolean pocetak = true;


    public static String prebaciUString(InputStream inputStream) {
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));

        StringBuilder stringBuilder = new StringBuilder();
        String linija;
        try {
            while ((linija = bufferedReader.readLine()) != null)
                stringBuilder.append(linija + "\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
        return stringBuilder.toString();

    }

    private void inicijalizirajKvizoveLista() {
        listaKvizovi = findViewById(R.id.lvKvizovi);
        kvizAdapter = new KvizAdapterLista(this, R.layout.element_liste, kvizoviUKategoriji);
        listaKvizovi.setAdapter(kvizAdapter);
    }

    private void inicijalizirajKategorijeSpinner() {
        spinnerKategorije = findViewById(R.id.spPostojeceKategorije);
        kategorijaAdapter = new KategorijaAdapterSpinner(this, R.layout.support_simple_spinner_dropdown_item, kategorije);
        spinnerKategorije.setAdapter(kategorijaAdapter);
    }


    private void detektujDugiKlikNaListuKvizova() {
        listaKvizovi.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {

            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                if (Mreza.getStatusMreze(view.getContext())) {
                    Intent dodajKvizAktivnost = new Intent(KvizoviAkt.this, DodajKvizAkt.class);
                    if (position != kvizoviUKategoriji.size() - 1)
                        dodajKvizAktivnost.putExtra("kvizId", kvizoviUKategoriji.get(position).getId());
                    KvizoviAkt.this.startActivity(dodajKvizAktivnost);
                } else {
                    AlertDialog alertDialog = new AlertDialog.Builder(KvizoviAkt.this).create();
                    alertDialog.setTitle("Greška");
                    alertDialog.setMessage("Nije moguće editovati kviz bez interneta");
                    alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "OK", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });
                    alertDialog.show();
                }
                return true;
            }
        });
    }

    private void detektujKratkiKlikNaListuKvizova() {
        listaKvizovi.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position == kvizoviUKategoriji.size() - 1) {
                    if (Mreza.getStatusMreze(view.getContext())) {
                        Intent dodajKvizAktivnost = new Intent(KvizoviAkt.this, DodajKvizAkt.class);
                        KvizoviAkt.this.startActivity(dodajKvizAktivnost);
                    } else {
                        AlertDialog alertDialog = new AlertDialog.Builder(KvizoviAkt.this).create();
                        alertDialog.setTitle("Greška");
                        alertDialog.setMessage("Nije moguće dodati kviz bez interneta.");
                        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "OK", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });
                        alertDialog.show();
                    }
                } else {
                    CalendarContentResolver contentResolver = new CalendarContentResolver(view.getContext());
                    boolean response = contentResolver.daLiPostojiDogadjaj((int) Math.ceil(((double) kvizoviUKategoriji.get(position).getPitanja().size()) / 2 + 1) * 60000);
                    if (response) {
                        Intent igrajKvizAktivnost = new Intent(KvizoviAkt.this, IgrajKvizoviAkt.class);
                        igrajKvizAktivnost.putExtra("kvizId", kvizoviUKategoriji.get(position).getId());
                        KvizoviAkt.this.startActivity(igrajKvizAktivnost);
                    } else {
                        AlertDialog alertDialog = new AlertDialog.Builder(KvizoviAkt.this).create();
                        alertDialog.setTitle("Greška");
                        alertDialog.setMessage("Imate događaj u kalendaru");
                        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });
                        alertDialog.show();
                    }
                }
            }
        });
    }

    private void detektujDugiKlikNaGridKvizova(String id) {
        if (Mreza.getStatusMreze(this)) {
            Intent dodajKvizAktivnost = new Intent(KvizoviAkt.this, DodajKvizAkt.class);
            if (id != null) dodajKvizAktivnost.putExtra("kvizId", id);
            KvizoviAkt.this.startActivity(dodajKvizAktivnost);
        } else {
            AlertDialog alertDialog = new AlertDialog.Builder(KvizoviAkt.this).create();
            alertDialog.setTitle("Greška");
            alertDialog.setMessage("Nije moguće editovati kviz bez interneta.");
            alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "OK", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                }
            });
            alertDialog.show();
        }
    }

    private void detektujKratkiKlikNaGridKvizova(String id) {
        if (id == null) {
            if (Mreza.getStatusMreze(this)) {
                Intent dodajKvizAktivnost = new Intent(KvizoviAkt.this, DodajKvizAkt.class);
                KvizoviAkt.this.startActivity(dodajKvizAktivnost);
            } else {

                AlertDialog alertDialog = new AlertDialog.Builder(KvizoviAkt.this).create();
                alertDialog.setTitle("Greška");
                alertDialog.setMessage("Nije moguće dodati kviz bez interneta.");
                alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                alertDialog.show();

            }
        } else {
            CalendarContentResolver contentResolver = new CalendarContentResolver(this);
            KvizoviDBOpenHelper kvizoviDBOpenHelper = new KvizoviDBOpenHelper(this, KvizoviDBOpenHelper.IME_BAZE_PODATAKA, null, KvizoviDBOpenHelper.VERZIJA_BAZE_PODATAKA);
            Kviz kviz = kvizoviDBOpenHelper.ucitajKviz(id);
            boolean response = contentResolver.daLiPostojiDogadjaj((int) Math.ceil(((double) kviz.getPitanja().size()) / 2 + 1) * 60000);
            if (response) {
                Intent igrajKvizAktivnost = new Intent(KvizoviAkt.this, IgrajKvizoviAkt.class);
                igrajKvizAktivnost.putExtra("kvizId", id);
                KvizoviAkt.this.startActivity(igrajKvizAktivnost);
            } else {
                AlertDialog alertDialog = new AlertDialog.Builder(KvizoviAkt.this).create();
                alertDialog.setTitle("Greška");
                alertDialog.setMessage("Imate događaj u kalendaru");
                alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                alertDialog.show();
            }
        }
    }

    private void detektujPromjenuKategorijeSpinner() {
        spinnerKategorije.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (Mreza.getStatusMreze(view.getContext()))
                    new UcitajKvizoveFirestoreTask(view.getContext(), ((Kategorija) spinnerKategorije.getSelectedItem()).getIdBaza()).execute("Ucitavanje kvizova");
                else {
                    ucitajKvizoveSQL(((Kategorija) spinnerKategorije.getSelectedItem()).getIdBaza());
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                return;
            }
        });
    }

    private void inicijalizirajFragmentKategorije() {
        Bundle argumentiKategorije = new Bundle();
        argumentiKategorije.putSerializable("kategorije", kategorije);

        listaFrag = new ListaFrag();
        listaFrag.setArguments(argumentiKategorije);
        fragmentManager.beginTransaction().replace(R.id.listPlace, listaFrag).commit();
    }

    private void inicijalizirajFragmentKvizova() {
        Bundle argumentiKvizovi = new Bundle();

        argumentiKvizovi.putSerializable("kategorije", kategorije);
        argumentiKvizovi.putSerializable("kvizovi", kvizoviUKategoriji);
        detailFrag = new DetailFrag();
        detailFrag.setArguments(argumentiKvizovi);
        fragmentManager.beginTransaction().replace(R.id.detailPlace, detailFrag).commit();
    }


    private void inicijalizirajFragmente() {
        inicijalizirajFragmentKategorije();
        inicijalizirajFragmentKvizova();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.kvizovi_akt);

        fragmentManager = getSupportFragmentManager();
        listPlace = findViewById(R.id.listPlace);
        detailPlace = findViewById(R.id.detailPlace);


        if (Mreza.getStatusMreze(this)) {
            new UcitajKategorijeFirestoreTask(this).execute("Ucitavanje kategorija");
            new UcitajKvizoveFirestoreTask(this, "0").execute("Ucitavanje kvizova");
        } else {
            ucitajKvizoveSQL("0");
            ucitajKategorijeSQL();
        }


        if (listPlace == null || detailPlace == null) {
            detektujDugiKlikNaListuKvizova();
            detektujKratkiKlikNaListuKvizova();
            detektujPromjenuKategorijeSpinner();
        } else {
            inicijalizirajFragmente();
        }
    }


    @Override
    public void onBackPressed() {
        this.finishAffinity();
        System.exit(0);
    }

    @Override
    public void onListItemClicked(String id) {
        if (Mreza.getStatusMreze(this)) {
            new UcitajKvizoveFirestoreTask(this, id).execute("Ucitavanje kvizova");
        } else {
            ucitajKvizoveSQL(id);
        }
    }

    @Override
    public void onGridItemClicked(String id, ArrayList<Kviz> kvizovi) {
        if (kvizovi != null) {
            kvizoviUKategoriji.clear();
            kvizoviUKategoriji.addAll(kvizovi);
        }
        detektujKratkiKlikNaGridKvizova(id);
    }

    @Override
    public void onLongGridItemClicked(String id) {
        detektujDugiKlikNaGridKvizova(id);
    }


    private class UcitajKategorijeFirestoreTask extends AsyncTask<String, Void, Void> implements IBaza {
        private HttpURLConnection conn;
        private Context context;

        public UcitajKategorijeFirestoreTask(Context context) {
            super();
            this.context = context;
        }

        @Override
        protected Void doInBackground(String... strings) {
            try {
                konektujNaBazu();

                JSONObject dokument = new JSONObject(prebaciUString(conn.getInputStream()));
                kategorije.clear();
                if (dokument.has("documents")) {
                    JSONArray array = dokument.getJSONArray("documents");
                    try {
                        for (int i = 0; i < array.length(); i++) {
                            String[] name = array.getJSONObject(i).getString("name").split("/");
                            JSONObject kategorijaNaziv = array.getJSONObject(i).getJSONObject("fields").getJSONObject("naziv");
                            JSONObject kategorijaId = array.getJSONObject(i).getJSONObject("fields").getJSONObject("idIkonice");
                            String naziv = kategorijaNaziv.getString("stringValue");
                            String id = ((Integer) kategorijaId.getInt("integerValue")).toString();
                            kategorije.add(new Kategorija(naziv, id, name[name.length - 1]));
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
            KvizoviDBOpenHelper kvizoviDBOpenHelper = new KvizoviDBOpenHelper(context, KvizoviDBOpenHelper.IME_BAZE_PODATAKA, null, KvizoviDBOpenHelper.VERZIJA_BAZE_PODATAKA);
            kvizoviDBOpenHelper.unesiKategorije(kategorije);
            kategorije.add(0, new Kategorija("Sve", "902", "0"));
            zatvoriKonekciju();
            return null;
        }

        @Override
        protected void onPreExecute() {
            if (listPlace == null || detailPlace == null) inicijalizirajKategorijeSpinner();
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            if (listPlace == null || detailPlace == null) kategorijaAdapter.notifyDataSetChanged();
            else inicijalizirajFragmentKategorije();
            Toast.makeText(context, "Ucitane su kategorije iz baze", Toast.LENGTH_SHORT).show();
        }

        @Override
        public void konektujNaBazu() throws IOException {
            InputStream is = getResources().openRawResource(R.raw.secret);
            GoogleCredential credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();
            String token = credentials.getAccessToken();
            String urlString = "https://firestore.googleapis.com/v1/projects/projekatrma/databases/(default)/documents/Kategorije?access_token=";
            URL url = new URL(urlString + URLEncoder.encode(token, "UTF-8"));
            conn = (HttpURLConnection) url.openConnection();
            System.out.print(urlString + token);

            conn.setRequestMethod("GET");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Accept", "application/json");
        }

        @Override
        public void zatvoriKonekciju() {
            conn.disconnect();
        }
    }

    public class UcitajKvizoveFirestoreTask extends AsyncTask<String, Void, Void> implements IBaza {
        private String idKategorije;
        private HttpURLConnection connKvizovi;
        private HttpURLConnection connKategorije;
        private HttpURLConnection connPitanja;
        private Context context;
        private ProgressDialog progressDialog = null;

        private ArrayList<Kategorija> kategorijeIzBaze = new ArrayList<>();
        private ArrayList<Pitanje> pitanjaIzBaze = new ArrayList<>();

        public UcitajKvizoveFirestoreTask(Context context, String idKategorije) {
            super();
            this.context = context;
            this.idKategorije = idKategorije;
        }

        @Override
        protected Void doInBackground(String... strings) {
            try {
                konektujNaBazu();
                try {
                    JSONObject dokumenti = new JSONObject(prebaciUString(connKategorije.getInputStream()));
                    JSONArray array;
                    kategorijeIzBaze.clear();
                    if (dokumenti.has("documents")) {
                        array = dokumenti.getJSONArray("documents");
                        for (int i = 0; i < array.length(); i++) {
                            String[] name = array.getJSONObject(i).getString("name").split("/");
                            JSONObject kategorijaNaziv = array.getJSONObject(i).getJSONObject("fields").getJSONObject("naziv");
                            JSONObject kategorijaId = array.getJSONObject(i).getJSONObject("fields").getJSONObject("idIkonice");
                            String naziv = kategorijaNaziv.getString("stringValue");
                            String id = ((Integer) kategorijaId.getInt("integerValue")).toString();
                            kategorijeIzBaze.add(new Kategorija(naziv, id, name[name.length - 1]));
                        }
                    }

                    kategorijeIzBaze.add(0, new Kategorija("Sve", "902", "0"));

                    dokumenti = new JSONObject(prebaciUString(connPitanja.getInputStream()));
                    if (dokumenti.has("documents")) {
                        array = dokumenti.getJSONArray("documents");
                        for (int i = 0; i < array.length(); i++) {
                            String[] name = array.getJSONObject(i).getString("name").split("/");
                            JSONObject pitanjeNaziv = array.getJSONObject(i).getJSONObject("fields").getJSONObject("naziv");
                            JSONObject indexTacnog = array.getJSONObject(i).getJSONObject("fields").getJSONObject("indexTacnog");
                            JSONArray odgovoriJSON = array.getJSONObject(i).getJSONObject("fields").getJSONObject("odgovori").getJSONObject("arrayValue").getJSONArray("values");
                            ArrayList<String> odgovori = new ArrayList<>();
                            for (int j = 0; j < odgovoriJSON.length(); j++)
                                odgovori.add(odgovoriJSON.getJSONObject(j).getString("stringValue"));
                            String naziv = pitanjeNaziv.getString("stringValue");
                            Integer tacan = indexTacnog.getInt("integerValue");
                            pitanjaIzBaze.add(new Pitanje(naziv, naziv, odgovori, odgovori.get(tacan), name[name.length - 1]));
                        }
                    }

                    kvizoviUKategoriji.clear();
                    dokumenti = new JSONObject(prebaciUString(connKvizovi.getInputStream()));
                    if (dokumenti.has("documents")) {
                        array = dokumenti.getJSONArray("documents");
                        for (int i = 0; i < array.length(); i++) {
                            String[] name = array.getJSONObject(i).getString("name").split("/");
                            String kvizNaziv = array.getJSONObject(i).getJSONObject("fields").getJSONObject("naziv").getString("stringValue");
                            String kvizKategorijaId = array.getJSONObject(i).getJSONObject("fields").getJSONObject("idKategorije").getString("stringValue");

                            if (kvizKategorijaId.equals(idKategorije) || idKategorije.equals("0")) {
                                Kategorija kategorija = null;
                                for (Kategorija temp : kategorijeIzBaze) {
                                    if (temp.getIdBaza().equals(kvizKategorijaId)) {
                                        kategorija = temp;
                                        break;
                                    }
                                }


                                ArrayList<Pitanje> pitanjaUKvizu = new ArrayList<>();
                                JSONObject pitanjaKvizNiz = array.getJSONObject(i).getJSONObject("fields").getJSONObject("pitanja").getJSONObject("arrayValue");
                                if (pitanjaKvizNiz.has("values")) {
                                    JSONArray pitanjaKvizId = pitanjaKvizNiz.getJSONArray("values");
                                    for (int j = 0; j < pitanjaKvizId.length(); j++) {
                                        String pitanjeId = pitanjaKvizId.getJSONObject(j).getString("stringValue");
                                        for (Pitanje pitanje : pitanjaIzBaze)
                                            if (pitanje.getId().equals(pitanjeId)) {
                                                pitanjaUKvizu.add(pitanje);
                                                break;
                                            }
                                    }
                                }
                                kvizoviUKategoriji.add(new Kviz(kvizNaziv, pitanjaUKvizu, kategorija, name[name.length - 1]));
                            }
                        }
                    }

                    if (idKategorije.equals("0") && pocetak) {
                        KvizoviDBOpenHelper kvizoviDBOpenHelper = new KvizoviDBOpenHelper(context, KvizoviDBOpenHelper.IME_BAZE_PODATAKA, null, KvizoviDBOpenHelper.VERZIJA_BAZE_PODATAKA);
                        kvizoviDBOpenHelper.unesiKvizove(kvizoviUKategoriji);
                        pocetak = false;
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            } catch (IOException e) {
                e.printStackTrace();
            }

            zatvoriKonekciju();
            return null;
        }

        @Override
        protected void onPreExecute() {
            progressDialog = ProgressDialog.show(context, "", "Ucitavam kvizove", true);
            if (listPlace == null || detailPlace == null) inicijalizirajKvizoveLista();
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            progressDialog.cancel();
            if (kvizoviUKategoriji.size() == 0 || !kvizoviUKategoriji.get(kvizoviUKategoriji.size() - 1).getNaziv().equals("Dodaj kviz"))
                kvizoviUKategoriji.add(new Kviz("Dodaj kviz", null, null, null));
            if (listPlace == null || detailPlace == null) kvizAdapter.notifyDataSetChanged();
            else inicijalizirajFragmentKvizova();
        }

        @Override
        public void konektujNaBazu() throws IOException {
            InputStream is = getResources().openRawResource(R.raw.secret);
            GoogleCredential credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();
            String token = credentials.getAccessToken();
            String urlString = "https://firestore.googleapis.com/v1/projects/projekatrma/databases/(default)/documents/Kategorije?access_token=";
            URL url = new URL(urlString + URLEncoder.encode(token, "UTF-8"));
            connKategorije = (HttpURLConnection) url.openConnection();

            connKategorije.setRequestMethod("GET");
            connKategorije.setRequestProperty("Content-Type", "application/json");
            connKategorije.setRequestProperty("Accept", "application/json");

            is = getResources().openRawResource(R.raw.secret);
            credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();
            token = credentials.getAccessToken();
            urlString = "https://firestore.googleapis.com/v1/projects/projekatrma/databases/(default)/documents/Pitanja?access_token=";
            url = new URL(urlString + URLEncoder.encode(token, "UTF-8"));
            connPitanja = (HttpURLConnection) url.openConnection();

            connPitanja.setRequestMethod("GET");
            connPitanja.setRequestProperty("Content-Type", "application/json");
            connPitanja.setRequestProperty("Accept", "application/json");

            is = context.getResources().openRawResource(R.raw.secret);
            credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();
            token = credentials.getAccessToken();
            urlString = "https://firestore.googleapis.com/v1/projects/projekatrma/databases/(default)/documents/Kvizovi?access_token=";
            url = new URL(urlString + URLEncoder.encode(token, "UTF-8"));
            connKvizovi = (HttpURLConnection) url.openConnection();

            connKvizovi.setRequestMethod("GET");
            connKvizovi.setRequestProperty("Content-Type", "application/json");
            connKvizovi.setRequestProperty("Accept", "application/json");
        }

        @Override
        public void zatvoriKonekciju() {
            connKategorije.disconnect();
            connPitanja.disconnect();
            connKvizovi.disconnect();
        }
    }


    private void ucitajKvizoveSQL(String idKategorije){
        if (listPlace == null || detailPlace == null) inicijalizirajKvizoveLista();
        KvizoviDBOpenHelper kvizoviDBOpenHelper = new KvizoviDBOpenHelper(this, KvizoviDBOpenHelper.IME_BAZE_PODATAKA, null, KvizoviDBOpenHelper.VERZIJA_BAZE_PODATAKA);
        kvizoviUKategoriji.clear();
        kvizoviUKategoriji.addAll(kvizoviDBOpenHelper.ucitajKvizove(idKategorije));
        kvizoviUKategoriji.add(new Kviz("Dodaj kviz", null, null, null));
        if (listPlace == null || detailPlace == null) kvizAdapter.notifyDataSetChanged();
        else inicijalizirajFragmentKvizova();
    }

    private void ucitajKategorijeSQL(){
        if (listPlace == null || detailPlace == null) inicijalizirajKategorijeSpinner();
        KvizoviDBOpenHelper kvizoviDBOpenHelper = new KvizoviDBOpenHelper(this, KvizoviDBOpenHelper.IME_BAZE_PODATAKA, null, KvizoviDBOpenHelper.VERZIJA_BAZE_PODATAKA);
        kategorije.clear();
        kategorije.addAll(kvizoviDBOpenHelper.ucitajKategorije());
        kategorije.add(0, new Kategorija("Sve", "902", "0"));
        if (listPlace == null || detailPlace == null) kategorijaAdapter.notifyDataSetChanged();
        else inicijalizirajFragmentKategorije();
    }
}
