package ba.unsa.etf.rma.fragmenti;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;

public class RangLista extends Fragment {
    private TextView tvRangLista;
    private ListView lvIgraci;
    private ArrayAdapter<String> rangListaAdapter;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_rang_lista, container, false);
        lvIgraci = view.findViewById(R.id.lvIgraci);
        tvRangLista = view.findViewById(R.id.tvRangLista);
        if(getArguments().getInt("pozicija") != -1){
            tvRangLista.setText(tvRangLista.getText().toString() + "\nVi ste na " + getArguments().getInt("pozicija") + ". poziciji");
        }
        else{
            tvRangLista.setText("\nRang lista nije dostupna");
        }

        return view;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        rangListaAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_list_item_1, getArguments().getStringArrayList("rangLista"));
        lvIgraci.setAdapter(rangListaAdapter);
    }


}
