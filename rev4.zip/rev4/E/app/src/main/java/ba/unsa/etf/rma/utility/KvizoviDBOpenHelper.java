package ba.unsa.etf.rma.utility;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

import ba.unsa.etf.rma.klase.IgraKviza;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;

public class KvizoviDBOpenHelper extends SQLiteOpenHelper {
    public static final String IME_BAZE_PODATAKA = "kvizovi.db";
    public static final int VERZIJA_BAZE_PODATAKA = 1;
    public static final String ID = "_id";
    public static final String ID_FIRESTORE = "idFirestore";

    public static final String TABELA_KVIZOVI = "Kvizovi";
    public static final String KVIZ_NAZIV = "naziv";
    public static final String KVIZ_KATEGORIJA_FK = "kategorija";

    public static final String TABELA_KATEGORIJE = "Kategorije";
    public static final String KATEGORIJA_NAZIV = "naziv";
    public static final String KATEGORIJA_IKONA = "ikona";

    public static final String TABELA_PITANJA = "Pitanja";
    public static final String PITANJE_NAZIV = "naziv";
    public static final String PITANJE_KVIZ_FK = "kviz";

    public static final String TABELA_ODGOVORI = "Odgovori";
    public static final String ODGOVOR_TEKST = "tekst";
    public static final String ODGOVOR_PITANJE_FK = "pitanje";
    public static final String ODGOVOR_TACAN = "tacan";

    public static final String TABELA_RANG_LISTE = "RangListe";
    public static final String RANG_LISTE_KVIZ_ID = "kviz";

    public static final String TABELA_RANG_LISTA = "RangLista";
    public static final String RANG_LISTA_IME = "ime";
    public static final String RANG_LISTA_PROCENAT_TACNIH = "procenat";
    public static final String RANG_LISTA_IZ_FIRESTORE = "firestore";
    public static final String RANG_LISTA_ID = "RangListaId";


    private static final String KVIZOVI_CREATE = "create table " + TABELA_KVIZOVI +
            " (" + ID + " integer primary key autoincrement, " +
            ID_FIRESTORE + " text unique, " +
            KVIZ_NAZIV + " text not null, " +
            KVIZ_KATEGORIJA_FK + " text not null, " +
            "foreign key (" + KVIZ_KATEGORIJA_FK + ") references " + TABELA_KATEGORIJE + "(" + ID_FIRESTORE + "));";

    private static final String KATEGORIJE_CREATE = "create table " + TABELA_KATEGORIJE +
            " (" + ID + " integer primary key autoincrement, " +
            ID_FIRESTORE + " text unique, " +
            KATEGORIJA_NAZIV + " text not null, " +
            KATEGORIJA_IKONA + " text not null);";

    private static final String PITANJA_CREATE = "create table " + TABELA_PITANJA +
            " (" + ID + " integer primary key autoincrement, " +
            ID_FIRESTORE + " text, " +
            PITANJE_NAZIV + " text not null, " +
            PITANJE_KVIZ_FK + " text not null, " +
            "foreign key (" + PITANJE_KVIZ_FK + ") references " + TABELA_KVIZOVI + "(" + ID_FIRESTORE + "));";

    private static final String ODGOVORI_CREATE = "create table " + TABELA_ODGOVORI +
            " (" + ID + " integer primary key autoincrement, " +
            ODGOVOR_TEKST + " text not null, " +
            ODGOVOR_TACAN + " integer not null, " +                         // 0 za netacan, bilo sta drugo za tacan
            ODGOVOR_PITANJE_FK + " text not null, " +
            "foreign key (" + ODGOVOR_PITANJE_FK + ") references " + TABELA_PITANJA + "(" + ID + "));";

    private static final String RANG_LISTE_CREATE = "create table " + TABELA_RANG_LISTE +
            " (" + ID + " integer primary key autoincrement, " +
            ID_FIRESTORE + " text unique, " +
            RANG_LISTE_KVIZ_ID + " text not null, " +
            "foreign key (" + RANG_LISTE_KVIZ_ID + ") references " + TABELA_KVIZOVI + "(" + ID_FIRESTORE + "));";

    private static final String RANG_LISTA_CREATE = "create table " + TABELA_RANG_LISTA +
            " (" + ID + " integer primary key autoincrement, " +
            RANG_LISTA_IME + " text not null, " +
            RANG_LISTA_PROCENAT_TACNIH + " real not null, " +
            RANG_LISTA_ID + " text not null, " +
            RANG_LISTA_IZ_FIRESTORE + "text not null, " + // 0 ako je ucitana na pocetku bilo sta drugo ako je dodana u offline mode - u
            "foreign key (" + RANG_LISTA_ID + ") references " + TABELA_RANG_LISTE + "(" + ID_FIRESTORE + "));";

    public void unesiKvizove(ArrayList<Kviz> kvizovi) {
        SQLiteDatabase db = this.getWritableDatabase();
        for (Kviz kviz : kvizovi) {
            if (!kviz.getNaziv().equals("Dodaj kviz")) {
                ContentValues contentValues = new ContentValues();
                contentValues.put(ID_FIRESTORE, kviz.getId());
                contentValues.put(KVIZ_NAZIV, kviz.getNaziv());
                contentValues.put(KVIZ_KATEGORIJA_FK, kviz.getKategorija().getIdBaza());
                db.insert(TABELA_KVIZOVI, null, contentValues);
                unesiPitanja(db, kviz.getPitanja(), kviz.getId());
            }
        }

        db.close();
    }

    private void unesiPitanja(SQLiteDatabase db, ArrayList<Pitanje> pitanja, String kvizId) {
        for (Pitanje pitanje : pitanja) {
            ContentValues contentValues = new ContentValues();
            contentValues.put(ID_FIRESTORE, pitanje.getId());
            contentValues.put(PITANJE_NAZIV, pitanje.getNaziv());
            contentValues.put(PITANJE_KVIZ_FK, kvizId);
            db.insert(TABELA_PITANJA, null, contentValues);
            unesiOdgovore(db, pitanje.getOdgovori(), pitanje.getTacan(), pitanje.getId());
        }
    }

    private void unesiOdgovore(SQLiteDatabase db, ArrayList<String> odgovori, String tacan, String pitanjeId) {
        for (int i = 0; i < odgovori.size(); i++) {
            ContentValues contentValues = new ContentValues();
            contentValues.put(ODGOVOR_TEKST, odgovori.get(i));
            contentValues.put(ODGOVOR_TACAN, tacan.equals(odgovori.get(i)) ? 1 : 0);
            contentValues.put(ODGOVOR_PITANJE_FK, pitanjeId);
            db.insert(TABELA_ODGOVORI, null, contentValues);
        }
    }

    private void unesiRangListe(ArrayList<ArrayList<IgraKviza>> rangListe) {
        for(int i = 0; i < rangListe.size(); i++){
            for(int j = 0; j < rangListe.get(i).size(); j++){

            }
        }
    }

    public void unesiKategorije(ArrayList<Kategorija> kategorije) {
        SQLiteDatabase db = this.getWritableDatabase();
        for (Kategorija kategorija : kategorije) {
            if (!kategorija.getNaziv().equals("Sve")) {
                ContentValues contentValues = new ContentValues();
                contentValues.put(ID_FIRESTORE, kategorija.getIdBaza());
                contentValues.put(KATEGORIJA_NAZIV, kategorija.getNaziv());
                contentValues.put(KATEGORIJA_IKONA, kategorija.getId());
                db.insert(TABELA_KATEGORIJE, null, contentValues);
            }
        }
        db.close();
    }

    public ArrayList<Kviz> ucitajKvizove(String kategorijaId) {
        ArrayList<Kviz> kvizovi = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        String[] kolone = new String[]{ID_FIRESTORE, KVIZ_NAZIV, KVIZ_KATEGORIJA_FK};
        String where = null;
        if(!kategorijaId.equals("0")) where = KVIZ_KATEGORIJA_FK + " = \"" + kategorijaId + "\"";
        Cursor cursorKviz = db.query(TABELA_KVIZOVI, kolone, where, null, null, null, null);
        if (!cursorKviz.moveToFirst()) return kvizovi;
        ArrayList<Kategorija> kategorije = ucitajKategorije();
        do {
            if (cursorKviz.getString(2).equals(kategorijaId) || kategorijaId.equals("0")) {
                Kategorija kategorija = new Kategorija("Sve", "902", "0");
                for (int i = 0; i < kategorije.size(); i++)
                    if (kategorije.get(i).getIdBaza().equals(cursorKviz.getString(2))) {
                        kategorija = kategorije.get(i);
                        break;
                    }
                ArrayList<Pitanje> pitanja = ucitajPitanja(cursorKviz.getString(0));
                Kviz kviz = new Kviz(cursorKviz.getString(1), pitanja, kategorija, cursorKviz.getString(0));
                kvizovi.add(kviz);
            }
        } while (cursorKviz.moveToNext());
        return kvizovi;
    }

    public ArrayList<Kategorija> ucitajKategorije() {
        ArrayList<Kategorija> kategorije = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        String[] kolone = new String[]{ID_FIRESTORE, KATEGORIJA_NAZIV, KATEGORIJA_IKONA};
        Cursor cursorKategorije = db.query(TABELA_KATEGORIJE, kolone, null, null, null, null, null);
        if (!cursorKategorije.moveToFirst()) return kategorije;
        do {
            Kategorija kategorija = new Kategorija(cursorKategorije.getString(1), cursorKategorije.getString(2), cursorKategorije.getString(0));
            kategorije.add(kategorija);
        } while (cursorKategorije.moveToNext());

        return kategorije;
    }

    public ArrayList<Pitanje> ucitajPitanja(String kvizId) {
        ArrayList<Pitanje> pitanja = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        String[] kolone = new String[]{ID_FIRESTORE, PITANJE_NAZIV, PITANJE_KVIZ_FK};
        Cursor cursorPitanja = db.query(TABELA_PITANJA, kolone, PITANJE_KVIZ_FK + " = " + "\"" + kvizId + "\"", null, null, null, null);
        if (!cursorPitanja.moveToFirst()) return pitanja;
        do {
            if(cursorPitanja.getString(2).equals(kvizId)) {
                ArrayList<String> odgovori = new ArrayList<>();
                SQLiteDatabase temp = getReadableDatabase();
                kolone = new String[]{ODGOVOR_TEKST, ODGOVOR_TACAN, ODGOVOR_PITANJE_FK};
                Cursor cursorOdgovori = temp.query(TABELA_ODGOVORI, kolone, ODGOVOR_PITANJE_FK + " = " + "\"" + cursorPitanja.getString(0) + "\"", null, null, null, null);
                String tacan = "";
                if (cursorOdgovori.moveToFirst()) {
                    do {
                        boolean postoji = false;
                        for(String odgovor : odgovori)
                            if(odgovor.equals(cursorOdgovori.getString(0))) postoji = true;
                        if(!postoji){
                            if (cursorOdgovori.getString(2).equals(cursorPitanja.getString(0))) {
                                odgovori.add(cursorOdgovori.getString(0));
                                if (cursorOdgovori.getInt(1) != 0) tacan = cursorOdgovori.getString(0);
                            }
                        }
                    } while (cursorOdgovori.moveToNext());
                }
                boolean postoji = false;
                for(Pitanje p : pitanja)
                    if(p.getId().equals(cursorPitanja.getString(0))) postoji = true;

                if(!postoji){
                    Pitanje pitanje = new Pitanje(cursorPitanja.getString(1), cursorPitanja.getString(1), odgovori, tacan, cursorPitanja.getString(0));
                    pitanja.add(pitanje);
                }

                temp.close();
            }
        } while (cursorPitanja.moveToNext());

        db.close();
        return pitanja;
    }

    public Kviz ucitajKviz(String id) {
        SQLiteDatabase db = getReadableDatabase();
        String[] kolone = new String[]{KVIZ_NAZIV, KVIZ_KATEGORIJA_FK};
        Cursor cursorKviz = db.query(TABELA_KVIZOVI, kolone, ID_FIRESTORE + " = " + "\"" + id + "\"", null, null, null, null);
        if (!cursorKviz.moveToFirst()) return null;
        ArrayList<Kategorija> kategorije = ucitajKategorije();
        ArrayList<Pitanje> pitanja = ucitajPitanja(id);

        Kategorija kategorija = new Kategorija("Sve", "902", "0");
        for (int i = 0; i < kategorije.size(); i++)
            if (kategorije.get(i).getIdBaza().equals(cursorKviz.getString(1))) {
                kategorija = kategorije.get(i);
                break;
            }
        Kviz kviz = new Kviz(cursorKviz.getString(0), pitanja, kategorija, id);
        return kviz;
    }

    public KvizoviDBOpenHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(KATEGORIJE_CREATE);
        db.execSQL(KVIZOVI_CREATE);
        db.execSQL(PITANJA_CREATE);
        db.execSQL(ODGOVORI_CREATE);
        db.execSQL(RANG_LISTA_CREATE);
        db.execSQL(RANG_LISTE_CREATE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS '" + TABELA_RANG_LISTE + "'");
        db.execSQL("DROP TABLE IF EXISTS '" + TABELA_RANG_LISTA + "'");
        db.execSQL("DROP TABLE IF EXISTS '" + TABELA_ODGOVORI + "'");
        db.execSQL("DROP TABLE IF EXISTS '" + TABELA_PITANJA + "'");
        db.execSQL("DROP TABLE IF EXISTS '" + TABELA_KVIZOVI + "'");
        db.execSQL("DROP TABLE IF EXISTS '" + TABELA_KATEGORIJE + "'");
        onCreate(db);
    }
}
