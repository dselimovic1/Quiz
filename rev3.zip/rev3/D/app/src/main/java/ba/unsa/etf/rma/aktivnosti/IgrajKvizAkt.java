package ba.unsa.etf.rma.aktivnosti;

import android.content.res.Configuration;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.fragmenti.DetailFrag;
import ba.unsa.etf.rma.fragmenti.InformacijeFrag;
import ba.unsa.etf.rma.fragmenti.ListaFrag;
import ba.unsa.etf.rma.fragmenti.PitanjeFrag;
import ba.unsa.etf.rma.fragmenti.RangLista;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;
import ba.unsa.etf.rma.klase.RangIgraca;
import ba.unsa.etf.rma.web.DodajIPovuciRankingOnline;

public class IgrajKvizAkt extends AppCompatActivity implements DodajIPovuciRankingOnline.onDodajIPovuciRankingOnlineDone{

    public static ArrayList<Kviz> kvizovi = new ArrayList<Kviz>(){{add(new Kviz("Dodaj kviz"));}};
    public static ArrayList<Kategorija> kategorije = new ArrayList<Kategorija>(){{add(0,new Kategorija("Svi","22"));}};
    public static ArrayList<Pitanje> neDodijeljenaPitanja = new ArrayList<>();
    public static Kviz odabraniKviz = new Kviz();
    public static int brojOdgovorenih = 0;
    public static float procenatTacnih = 100;
    public static int brojTacnih = 0;
    public static String nazivIgraca;
    public static String nazivKviza;
    public static String proce;
    public static void zamijeniFragmente(){}

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_igraj_kviz_akt);

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            ArrayList<Kategorija> kat = extras.getParcelableArrayList("kategorije");
            ArrayList<Kviz> kviz = extras.getParcelableArrayList("kvizovi");
            ArrayList<Pitanje> pit = extras.getParcelableArrayList("nedodijeljenaPitanja");

            if(kat!=null){
                for(int i=0;i<kategorije.size();i++){
                    kategorije.remove(i);
                    i--;
                }
                kategorije.addAll(kat);
            }
            if(kviz!=null){
                for(int i=0;i<kvizovi.size();i++){
                    kvizovi.remove(i);
                    i--;
                }
                kvizovi.addAll(kviz);
            }
            if(pit!=null){
                for(int i=0;i<neDodijeljenaPitanja.size();i++){
                    neDodijeljenaPitanja.remove(i);
                    i--;
                }
                neDodijeljenaPitanja.addAll(pit);
            }
            odabraniKviz= extras.getParcelable("odabraniKviz");
        }
        Configuration config = getResources().getConfiguration();

        android.support.v4.app.FragmentTransaction ft = getSupportFragmentManager().beginTransaction();

        PitanjeFrag pf = new PitanjeFrag();
        Bundle pfBundle = new Bundle();
        pfBundle.putParcelableArrayList("kategorije",kategorije);
        pfBundle.putParcelableArrayList("nedodijeljenaPitanja",neDodijeljenaPitanja);
        pfBundle.putParcelableArrayList("kvizovi",kvizovi);
        InformacijeFrag iif = new InformacijeFrag();

        Bundle ifBundle = new Bundle();
        ifBundle.putParcelableArrayList("kvizovi",kvizovi);
        ifBundle.putParcelableArrayList("kategorije",kategorije);
        ifBundle.putParcelableArrayList("nedodijeljenaPitanja",neDodijeljenaPitanja);

        pf.setArguments(pfBundle);
        iif.setArguments(ifBundle);

        ft.replace(R.id.informacijePlace,iif);
        ft.replace(R.id.pitanjePlace,pf);
        ft.commit();
    }
    public static void ucitajRankingSaInterneta(RangIgraca rangic){

    }

    @Override
    public void onDIPRankingDone(ArrayList<RangIgraca> ranking) {
        //RangLista.osvjeziRangListu(ranking);
    }
}
