package ba.unsa.etf.rma.aktivnosti;

import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.app.ListFragment;
import android.content.Intent;
import android.content.res.Configuration;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import ba.unsa.etf.rma.DodatneImplementacije.KategorijeSpinner;
import ba.unsa.etf.rma.KvizAdapter;
import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.adapteri.KvizBaseAdapter;
import ba.unsa.etf.rma.fragmenti.DetailFrag;
import ba.unsa.etf.rma.fragmenti.ListaFrag;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;
import ba.unsa.etf.rma.web.UcitajKategorijeOnline;
import ba.unsa.etf.rma.web.UcitajKvizoveOnline;

public class KvizoviAkt extends AppCompatActivity implements UcitajKategorijeOnline.onUcitajKategorijeOnlineDone, UcitajKvizoveOnline.OnUcitajKvizoveOnlineDone {
    public static int brojPokretanja = 0;
    public static int brojKlikovaNaSpinner = 0;
    public ArrayList<Kviz> kvizovi = new ArrayList<Kviz>(){{add(new Kviz("Dodaj kviz"));}};
    public static ArrayList<Kategorija> kategorije = new ArrayList<Kategorija>()/*{{add(0,new Kategorija("Svi","22"));}}*/;
    public ArrayList<Pitanje> neDodijeljenaPitanja = new ArrayList<>();
    public ArrayAdapter<String> kategorijeAdapter;
    public static ArrayList<String> kategorijice = new ArrayList<>();
    public KvizBaseAdapter adapter;
    public ListView listaKvizova;
    public static void setKategorije(ArrayList<Kategorija> kategorije1){
        kategorije = kategorije1;
        kategorijice.clear();
        for(int i=0;i<kategorije.size();i++){kategorijice.add(kategorije.get(i).getNaziv()); }
    }
    public KategorijeSpinner spPostojeceKategorije;
    public void applyHardCodedData(){
        ArrayList<Pitanje> pitanjanekakva = new ArrayList<>();
        kategorije.add(new Kategorija("Dosadni","220"));
        kategorije.add(new Kategorija("Zabavni","219"));
        ArrayList<String> odgovorici = new ArrayList<>();
        odgovorici.add("Ne");
        odgovorici.add("Da");
        odgovorici.add("Ne");
        odgovorici.add("Svejedno mi je");
        odgovorici.add("Sta ja znam");
        odgovorici.add("Ne");
        odgovorici.add("Da");
        odgovorici.add("Ne");
        odgovorici.add("Svejedno mi je");
        odgovorici.add("Sta ja znam");

        Pitanje pitanje1 = new Pitanje("Da li ste fini?","Da li je ovo glup projekat?",odgovorici,"Da");
        Pitanje pitanje2 = new Pitanje("Da li ste normalni?","Da li je ovo glup projekat?",odgovorici,"Da");
        Pitanje pitanje3 = new Pitanje("Da li ste dobri?","Da li je ovo glup projekat?",odgovorici,"Da");
        neDodijeljenaPitanja.add(new Pitanje("Da li ste dobri u glavu?","Da li je ovo glup projekat?",odgovorici,"Da"));
        neDodijeljenaPitanja.add(new Pitanje("Da li ste pametni?","Da li je ovo glup projekat?",odgovorici,"Da"));
        neDodijeljenaPitanja.add(new Pitanje("Vi ste najjaci","Da li je ovo glup projekat?",odgovorici,"Da"));

        pitanjanekakva.add(pitanje1);
        pitanjanekakva.add(pitanje2);
        pitanjanekakva.add(pitanje3);
        kvizovi.add(0,new Kviz("Kviz 1",kategorije.get(1),pitanjanekakva));
        kvizovi.add(0,new Kviz("Kviz 2",kategorije.get(1),pitanjanekakva));
        kvizovi.add(0,new Kviz("Kviz 3",kategorije.get(1)));
        kvizovi.add(0,new Kviz("Kviz 4",kategorije.get(2)));
        kvizovi.add(0,new Kviz("Kviz 5",kategorije.get(2)));
        kvizovi.add(0,new Kviz("Kviz 6",kategorije.get(2)));
        kvizovi.add(0,new Kviz("Kviz 7",kategorije.get(1),pitanjanekakva));
        kvizovi.add(0,new Kviz("Kviz 8",kategorije.get(1),pitanjanekakva));
        kvizovi.add(0,new Kviz("Kviz 9",kategorije.get(1)));
        kvizovi.add(0,new Kviz("Kviz 10",kategorije.get(2)));
        kvizovi.add(0,new Kviz("Kviz 11",kategorije.get(2)));
        kvizovi.add(0,new Kviz("Kviz 12",kategorije.get(2)));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        this.brojKlikovaNaSpinner=0;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kvizovi_akt);

        /*Bundle extras = getIntent().getExtras();
        if (extras != null) {
            ArrayList<Kategorija> kat = extras.getParcelableArrayList("kategorije");
            ArrayList<Kviz> kviz = extras.getParcelableArrayList("kvizovi");
            ArrayList<Pitanje> pit = extras.getParcelableArrayList("nedodijeljenaPitanja");

            if(kat!=null){
                for(int i=0;i<kategorije.size();i++){
                    kategorije.remove(i);
                    i--;
                }
                kategorije.addAll(kat);
            }
            if(kviz!=null){
                for(int i=0;i<kvizovi.size();i++){
                    kvizovi.remove(i);
                    i--;
                }
                kvizovi.addAll(kviz);
            }
            if(pit!=null){
                for(int i=0;i<neDodijeljenaPitanja.size();i++){
                    neDodijeljenaPitanja.remove(i);
                    i--;
                }
                neDodijeljenaPitanja.addAll(pit);
            }
        }
        else{

        }*/
        //if(brojPokretanja==0)applyHardCodedData();

        //applyHardCodedData();
        /* Kategorije i hint da stoji naziv Kategorije u spinneru */
        kategorijice = new ArrayList<>();
        new UcitajKategorijeOnline(KvizoviAkt.this,"Kategorije",(UcitajKategorijeOnline.onUcitajKategorijeOnlineDone)KvizoviAkt.this).execute("");
        for(int i=0;i<kategorije.size();i++){kategorijice.add(kategorije.get(i).getNaziv());}
        spPostojeceKategorije = (KategorijeSpinner)findViewById(R.id.spPostojeceKategorije);

        if(spPostojeceKategorije==null){
            Configuration config = getResources().getConfiguration();

            android.support.v4.app.FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            ListaFrag lf = new ListaFrag();
            Bundle lfBundle = new Bundle();
            lfBundle.putParcelableArrayList("kategorije",kategorije);
            lfBundle.putParcelableArrayList("nedodijeljenaPitanja",neDodijeljenaPitanja);
            lfBundle.putParcelableArrayList("kvizovi",kvizovi);
            DetailFrag df = new DetailFrag();
            Bundle dfBundle = new Bundle();
            dfBundle.putParcelableArrayList("kvizovi",kvizovi);
            dfBundle.putParcelableArrayList("kategorije",kategorije);
            dfBundle.putParcelableArrayList("nedodijeljenaPitanja",neDodijeljenaPitanja);

            lf.setArguments(lfBundle);
            df.setArguments(dfBundle);

            ft.replace(R.id.listPlace,lf);
            ft.replace(R.id.detailPlace,df);
            ft.commit();
        }
        else{


            kategorijeAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,kategorijice);
            spPostojeceKategorije.setAdapter(kategorijeAdapter);

            listaKvizova = (ListView)findViewById(R.id.lvKvizovi);
            adapter = new KvizBaseAdapter(getApplicationContext(),kvizovi);
            //final KvizAdapter adapter = new KvizAdapter(this,kvizovi);
            listaKvizova.setAdapter(adapter);
            adapter.notifyDataSetChanged();

        final ArrayList<Kategorija> finalKategorije = kategorije;
        listaKvizova.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if(!adapter.getItem(position).getNaziv().equals("Dodaj kviz")){
                    Bundle bundle = new Bundle();
                    bundle.putParcelableArrayList("kategorije",kategorije);
                    bundle.putParcelableArrayList("nedodijeljenaPitanja",neDodijeljenaPitanja);
                    bundle.putParcelableArrayList("kvizovi",kvizovi);
                    int indeks=0;
                    for (int i = 0; i < kvizovi.size(); i++) {
                        if (kvizovi.get(i).getNaziv().equals(adapter.getItem(position).getNaziv())){
                            indeks = i;
                        }
                    }
                    bundle.putParcelable("odabraniKviz",kvizovi.get(indeks));
                    bundle.putInt("pozicijaOdabranogKviza",indeks);
                    Intent intent = new Intent(KvizoviAkt.this,IgrajKvizAkt.class);
                    intent.putExtras(bundle);
                    startActivity(intent);
                }
            }
        });
        listaKvizova.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                Bundle bundle = new Bundle();
                bundle.putParcelableArrayList("kategorije",kategorije);
                bundle.putParcelableArrayList("kvizovi",kvizovi);
                bundle.putParcelableArrayList("nedodijeljenaPitanja",neDodijeljenaPitanja);
                int indeks=0;
                for (int i = 0; i < kvizovi.size(); i++) {
                    if (kvizovi.get(i).getNaziv().equals(adapter.getItem(position).getNaziv())){
                        indeks = i;
                    }
                }
                bundle.putParcelable("odabraniKviz",kvizovi.get(indeks));
                bundle.putInt("pozicijaOdabranogKviza",indeks);
                Intent intent = new Intent(KvizoviAkt.this,DodajKvizAkt.class);
                intent.putExtras(bundle);
                startActivity(intent);
                return true;
            }
        });
        spPostojeceKategorije.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if(brojKlikovaNaSpinner>0)new UcitajKvizoveOnline(KvizoviAkt.this,spPostojeceKategorije.getSelectedItem().toString(),"Kvizovi",(UcitajKvizoveOnline.OnUcitajKvizoveOnlineDone)KvizoviAkt.this).execute("");
                brojKlikovaNaSpinner++;
                //adapter.getFilter().filter(spPostojeceKategorije.getSelectedItem().toString());
                //listaKvizova.invalidateViews();
                //listaKvizova.refreshDrawableState();
                //new UcitajKvizoveOnline(KvizoviAkt.this,spPostojeceKategorije.getSelectedItem().toString(),"Kvizovi",(UcitajKvizoveOnline.OnUcitajKvizoveOnlineDone)KvizoviAkt.this).execute("");
                listaKvizova.setAdapter(adapter);
                adapter.updateAdapter(kvizovi);
                adapter.notifyDataSetChanged();
                listaKvizova.invalidateViews();
                listaKvizova.invalidate();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                //adapter.getFilter().filter(spPostojeceKategorije.getSelectedItem().toString());
            }
        });
        listaKvizova.setAdapter(adapter);
        adapter.updateAdapter(kvizovi);
        adapter.notifyDataSetChanged();
        listaKvizova.invalidateViews();
        }
    }
    @Override
    protected void onStart(){
        super.onStart();
        this.brojKlikovaNaSpinner=0;
        if(kategorijeAdapter!=null){
            kategorijeAdapter.notifyDataSetChanged();
        }
        brojPokretanja++;

    }

    @Override
    public void onKategorijeDone(ArrayList<Kategorija> k) {
        kategorije.clear();
        kategorije.addAll(k);
        kategorijice.clear();
        //kategorije = k;
        for(int i=0;i<kategorije.size();i++){kategorijice.add(kategorije.get(i).getNaziv());}kategorijeAdapter.notifyDataSetChanged();
        spPostojeceKategorije.setSelection(kategorijice.indexOf("Svi"));this.brojPokretanja++;this.brojKlikovaNaSpinner++;
        //new UcitajKvizoveOnline(KvizoviAkt.this,"Svi","Kvizovi",(UcitajKvizoveOnline.OnUcitajKvizoveOnlineDone)KvizoviAkt.this).execute("");
    }

    @Override
    public void onUcitajKvizoveDone(ArrayList<Kviz> kvizovi) {
        for(int i=0;i<this.kvizovi.size()-1;i++){
            this.kvizovi.remove(i);
            i--;
        }
        this.kvizovi.addAll(0,kvizovi);
        adapter.notifyDataSetChanged();
        listaKvizova.invalidate();
        Toast.makeText(KvizoviAkt.this,"Zavrseno dovlacenje kvizova",Toast.LENGTH_SHORT).show();
        //spPostojeceKategorije.setSelection(kategorijice.size()-1);
    }
}
