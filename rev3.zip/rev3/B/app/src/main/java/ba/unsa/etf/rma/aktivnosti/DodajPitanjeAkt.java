package ba.unsa.etf.rma.aktivnosti;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import ba.unsa.etf.rma.ListaOdgovoraAdapter;
import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Pitanje;

public  class DodajPitanjeAkt extends AppCompatActivity {
    private EditText nazivPitanja;
    private EditText odgovor;
    private ListView listaOdgovora;
    private Button dodajOdg;
    private Button dodajTac;
    private Button zavrsi;
    private String tekstPitanja, tekstOdgovora,tacan;
    boolean postojiTacan=false;
    private ArrayList<String> odgovori=new ArrayList<>();
    private boolean postojiUBazi=false;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dodavanje_pitanja);
        dodajOdg = findViewById(R.id.btnDodajOdgovor);
        dodajTac = findViewById(R.id.btnDodajTacan);
        zavrsi = findViewById(R.id.btnDodajPitanje);
        nazivPitanja = (EditText) findViewById(R.id.etNaziv);
        odgovor = (EditText) findViewById(R.id.etOdgovor);
        listaOdgovora = (ListView) findViewById(R.id.lvOdgovori);
        Resources res = getResources();
        final ListaOdgovoraAdapter adapter;
        adapter = new ListaOdgovoraAdapter(this, odgovori, res);
        listaOdgovora.setAdapter(adapter);
        odgovor.setHint("Odgovor");
        nazivPitanja.setHint("Naziv pitanja - INPUT");

        nazivPitanja.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable s) {
                tekstPitanja = String.valueOf(nazivPitanja.getText());
            }

            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                nazivPitanja.setBackgroundColor(Color.parseColor("#ffffff"));

            }

            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }
        });

        odgovor.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable s) {
                tekstOdgovora = String.valueOf(odgovor.getText());
            }

            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                odgovor.setBackgroundColor(Color.parseColor("#ffffff"));
            }

            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }
        });

        dodajOdg.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (odgovor.getText().toString().trim().isEmpty() || odgovori.contains(odgovor.getText().toString())) {
                } else {
                    odgovori.add(tekstOdgovora);
                    adapter.notifyDataSetChanged();
                }
                odgovor.setText("");
            }
        });

        dodajTac.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (odgovor.getText().toString().trim().isEmpty() || odgovori.contains(odgovor.getText().toString())) {
                } else {
                    odgovori.add(tekstOdgovora);
                    postojiTacan = true;
                    tacan=tekstOdgovora.toString();
                    adapter.setPostojiTacan(true);
                    adapter.setTacan(tekstOdgovora);
                    dodajTac.setEnabled(false);
                    adapter.notifyDataSetChanged();
                }
                odgovor.setText("");
            }
        });

        listaOdgovora.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if(!odgovori.isEmpty()){
               if(odgovori.get(position).equals(tacan)){
                   dodajTac.setEnabled(true);
                   adapter.setPostojiTacan(false);
                   adapter.setTacan("");
                   tacan="";
                   postojiTacan=false;
               }
                odgovori.remove(position);
                adapter.notifyDataSetChanged();}
            }});
        listaOdgovora.setOnTouchListener(new View.OnTouchListener() {
            // Setting on Touch Listener for handling the touch inside ScrollView
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                // Disallow the touch request for parent scroll on touch of child view
                v.getParent().requestDisallowInterceptTouchEvent(true);
                return false;
            }
        });

        zavrsi.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                new PostojanjePitanja().execute(nazivPitanja.getText().toString().trim());
            }
        });
    }

    private class BazaZaDodavanje extends AsyncTask<Object,Void,Void> {
        @Override
        protected Void doInBackground(Object... objects) {
            GoogleCredential credentials;
            try {
                Pitanje p=(Pitanje)objects[0];

                InputStream is = getResources().openRawResource(R.raw.secret);
                credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();
                String TOKEN = credentials.getAccessToken();
                Log.d("tokennn","++"+TOKEN);

                String url="https://firestore.googleapis.com/v1/projects/rma-radusicesmina94/databases/(default)/documents/";
                url+="Pitanja/"+p.getNaziv()+"/?access_token="+TOKEN;
                Log.d("tokenich", TOKEN);
                URL urlObj=new URL(url);
                HttpURLConnection conn=(HttpURLConnection)urlObj.openConnection();
                conn.setDoOutput(true);
                conn.setRequestMethod("PATCH");
                conn.setRequestProperty("Content-type","application/json");
                conn.setRequestProperty("Accept","application/json");

                String dokument ="{\"fields\": {\n" +
                        "        \"indexTacnog\": {\n" +
                        "          \"integerValue\": \""+p.getOdgovori().indexOf(p.getTacan())+"\"\n" +
                        "        },\n" +
                        "        \"naziv\": {\n" +
                        "          \"stringValue\": \""+p.getNaziv()+"\"\n" +
                        "        },\n" +
                        "        \"odgovori\": {\n" +
                        "          \"arrayValue\": {\n" +
                        "            \"values\": [";
                String odgs="";
                for (int i = 0; i < p.getOdgovori().size(); i++) {
                    odgs+=  "{\"stringValue\": \""+p.getOdgovori().get(i)+"\"}";
                    if(i<p.getOdgovori().size()-1)odgs+=",";
                }
                dokument+=odgs;
                dokument+="]}}}}";

                try (OutputStream os=conn.getOutputStream()){
                    byte[] input = dokument.getBytes("utf-8");
                    os.write(input, 0, input.length);
                }
                Log.e("poop2", conn.getResponseCode() + ": " +conn.getResponseMessage());
            } catch (IOException e) {
                e.printStackTrace();
                Log.d("izuzetak","krah");

            }
            return null;
        }
    }
    private class PostojanjePitanja extends AsyncTask<Object,Void,Void>{

        @Override
        protected Void doInBackground(Object... objects) {
            GoogleCredential credentials;
            String TOKEN = "";
            try {
                InputStream is = getResources().openRawResource(R.raw.secret);
                credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();
                TOKEN = credentials.getAccessToken();
                String query="{\"structuredQuery\":{\"where\":{\"fieldFilter\":{\"field\":{\"fieldPath\":\"naziv\"},\"op\":\"EQUAL\"," +
                        "\"value\":{\"stringValue\":\""+(String)objects[0]+"\"}}}," +
                        "\"select\":{\"fields\":[{\"fieldPath\":\"naziv\"}]}," +
                        "\"from\":[{\"collectionId\":\"Pitanja\"}],\"limit\":1000}}";
                String url="https://firestore.googleapis.com/v1/projects/rma-radusicesmina94/databases/(default)/documents:runQuery?access_token="+ TOKEN;
                URL urlObj=new URL(url);
                HttpURLConnection conn=(HttpURLConnection)urlObj.openConnection();
                conn.setDoInput(true);
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-type","application/json");
                conn.setRequestProperty("Accept","application/json");
                try (OutputStream os=conn.getOutputStream()){
                    byte[] input = query.getBytes("utf-8");
                    os.write(input, 0, input.length);
                }
                InputStream odgovor=conn.getInputStream();
                String rezultat="";
                try(BufferedReader br= new BufferedReader(
                        new InputStreamReader(odgovor,"utf-8"))){
                    StringBuilder response = new StringBuilder();
                    String responseLine = null;
                    while((responseLine = br.readLine())!=null){
                        response.append(responseLine.trim());
                    }
                    rezultat =  "{ \"documents\": " + response.toString() + "}";
                    JSONObject object = new JSONObject(rezultat);
                    JSONArray niz=object.getJSONArray("documents");
                    for (int i =0;i<niz.length();i++){
                        if(niz.getJSONObject(i).has("document")) { postojiUBazi=true; break;}
                    }
                    Log.e("potraga", conn.getResponseCode() + ": " +conn.getResponseMessage());
                    Log.d("ispis rezutata", rezultat);
                    Log.d("ispis rezultata bool", "doInBackground: "+postojiUBazi);

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            } catch (IOException e) {
                e.printStackTrace();
            }

            return  null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            if(!postojiTacan || nazivPitanja.getText().toString().trim().isEmpty() ){
                if(odgovor.getText().toString().trim().isEmpty() && !postojiTacan){
                    odgovor.setBackgroundColor(Color.parseColor("#f4b2ae"));
                }
                 if(nazivPitanja.getText().toString().trim().isEmpty()){
                    nazivPitanja.setBackgroundColor(Color.parseColor("#f4b2ae"));
                }} else if(postojiUBazi){ dajAlert("Uneseno pitanje vec postoji!"); postojiUBazi=false;}
                else{
                Pitanje p= new Pitanje(tekstPitanja,tekstPitanja,tacan,odgovori);
                new BazaZaDodavanje().execute(p);
                Intent myIntent = new Intent(DodajPitanjeAkt.this, DodajKvizAkt.class);
                myIntent.putExtra("pitanje",p);
                setResult(2);
                setResult(RESULT_OK,myIntent);
                finish();}
        }
    }
    public  void dajAlert(String s){
        AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
        builder1.setMessage(s);
        builder1.setCancelable(true);
        builder1.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                dialog.cancel();
            }
        });
        AlertDialog alert11 = builder1.create();
        alert11.show();
    }
}
