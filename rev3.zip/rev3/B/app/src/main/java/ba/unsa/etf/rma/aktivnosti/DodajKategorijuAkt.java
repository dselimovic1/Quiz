package ba.unsa.etf.rma.aktivnosti;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;
import com.maltaisn.icondialog.Icon;
import com.maltaisn.icondialog.IconDialog;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kategorija;

public class DodajKategorijuAkt extends AppCompatActivity implements  IconDialog.Callback{
    private EditText naziv;
    private EditText idIkone;
    private Button ikona;
    private Button dodajKategoriju;
    private String ime, id;
    private Kategorija nova=new Kategorija();
    private IconDialog iconDialog;
    private Icon selectedIcons[];
    private boolean postojiUBazi=false;

    private class UnosKategorijeUBazu  extends AsyncTask<Object,Void,Void> {
        public void dodajKategorijuUBazu(Kategorija k){
            String kategorija= "{\"fields\": {\"idIkonice\": {\"integerValue\": \""+k.getId()+"\"},\"naziv\": {\"stringValue\": \""+k.getNaziv()+"\"}}}";
            this.execute("dodajKategoriju", k.getNaziv(), kategorija);
        }

        @Override
        protected Void doInBackground(Object... objects) {
            GoogleCredential credentials;
            try {
                InputStream is = getResources().openRawResource(R.raw.secret);
                credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();
                String TOKEN = credentials.getAccessToken();
                Log.d("tokennn","++"+TOKEN);

                String url="https://firestore.googleapis.com/v1/projects/rma-radusicesmina94/databases/(default)/documents/";
                if(((String)objects[0]).equals("dodajKategoriju")){
                    url+="Kategorije/"+((String)objects[1])+"/?access_token=";
                }
                url+=TOKEN;
                Log.d("tokenich", TOKEN);
                URL urlObj=new URL(url);
                HttpURLConnection conn=(HttpURLConnection)urlObj.openConnection();
                conn.setDoOutput(true);
                conn.setRequestMethod("PATCH");
                conn.setRequestProperty("Content-type","application/json");
                conn.setRequestProperty("Accept","application/json");

                String dokument ="";
                if(((String)objects[0]).equals("dodajKategoriju")){
                    dokument=((String)objects[2]);
                }

                try (OutputStream os=conn.getOutputStream()){
                    byte[] input = dokument.getBytes("utf-8");
                    os.write(input, 0, input.length);
                }
                Log.e("poop", conn.getResponseCode() + ": " +conn.getResponseMessage());
            } catch (IOException e) {
                e.printStackTrace();
                Log.d("izuzetak","krah");

            }
                return null;
        }
    }

    private class PostojanjeKategorije extends AsyncTask<Object,Void,Void>{

        @Override
        protected Void doInBackground(Object... objects) {
            GoogleCredential credentials;
            String TOKEN = "";
            try {
                InputStream is = getResources().openRawResource(R.raw.secret);
                credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();
                TOKEN = credentials.getAccessToken();
                String query="{\"structuredQuery\":{\"where\":{\"fieldFilter\":{\"field\":{\"fieldPath\":\"naziv\"},\"op\":\"EQUAL\"," +
                        "\"value\":{\"stringValue\":\""+(String)objects[0]+"\"}}}," +
                        "\"select\":{\"fields\":[{\"fieldPath\":\"idIkonice\"},{\"fieldPath\":\"naziv\"}]}," +
                        "\"from\":[{\"collectionId\":\"Kategorije\"}],\"limit\":1000}}";
                String url="https://firestore.googleapis.com/v1/projects/rma-radusicesmina94/databases/(default)/documents:runQuery?access_token="+ URLEncoder.encode(TOKEN, "UTF-8");
                URL urlObj=new URL(url);
                HttpURLConnection conn=(HttpURLConnection)urlObj.openConnection();
                conn.setDoInput(true);
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-type","application/json");
                conn.setRequestProperty("Accept","application/json");
                try (OutputStream os=conn.getOutputStream()){
                    byte[] input = query.getBytes("utf-8");
                    os.write(input, 0, input.length);
                }
                int code= conn.getResponseCode();
//                InputStream stream = conn.getErrorStream();
//                String greska="";
//                try(BufferedReader br= new BufferedReader(
//                        new InputStreamReader(stream,"utf-8"))){
//                    StringBuilder response = new StringBuilder();
//                    String responseLine = null;
//                    while((responseLine = br.readLine())!=null){
//                        response.append(responseLine.trim());
//                    }
//                    greska =  "{ \"documents\": " + response.toString() + "}";
//                    JSONObject object = new JSONObject(greska);
//                    JSONArray niz=object.getJSONArray("documents");
//                    for (int i =0;i<niz.length();i++){
//                        if(niz.getJSONObject(i).has("document"))  postojiUBazi=true;
//                    }
//                    Log.d("ispis greske", greska);
//
//                } catch (JSONException e) {
//                    e.printStackTrace();
//                }
                InputStream odgovor=conn.getInputStream();
                String rezultat="";
                try(BufferedReader br= new BufferedReader(
                        new InputStreamReader(odgovor,"utf-8"))){
                    StringBuilder response = new StringBuilder();
                    String responseLine = null;
                    while((responseLine = br.readLine())!=null){
                        response.append(responseLine.trim());
                    }
                    rezultat =  "{ \"documents\": " + response.toString() + "}";
                    JSONObject object = new JSONObject(rezultat);
                    JSONArray niz=object.getJSONArray("documents");
                    for (int i =0;i<niz.length();i++){
                        if(niz.getJSONObject(i).has("document")) { postojiUBazi=true; break;}
                    }
                    Log.e("potraga", conn.getResponseCode() + ": " +conn.getResponseMessage());
                    Log.d("ispis rezutata", rezultat);

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            } catch (IOException e) {
                e.printStackTrace();
            }

            return  null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            if ((naziv.getText().toString().trim().isEmpty() || idIkone.getText().toString().trim().isEmpty())) {
                if (naziv.getText().toString().trim().isEmpty() ) naziv.setBackgroundColor(Color.parseColor("#f4b2ae"));
                if (idIkone.getText().toString().trim().isEmpty() ) idIkone.setBackgroundColor(Color.parseColor("#f4b2ae"));
            } else if(postojiUBazi){
                dajAlert("Unesena kategorija vec postoji!");
                postojiUBazi=false;
            }else{
                new UnosKategorijeUBazu().dodajKategorijuUBazu(nova);
                Intent myIntent = new Intent(DodajKategorijuAkt.this, DodajKvizAkt.class);
                myIntent.putExtra("kategorija", nova);
                setResult(3);
                setResult(RESULT_OK, myIntent);
                finish();
            }
        }
    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dodavanje_kategorije);
        naziv=findViewById(R.id.etNaziv);
        idIkone=findViewById(R.id.etIkona);
        idIkone.setEnabled(false);
        ikona=findViewById(R.id.btnDodajIkonu);
        dodajKategoriju=findViewById(R.id.btnDodajKategoriju);

        naziv.addTextChangedListener(new TextWatcher() {

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                naziv.setBackgroundColor(Color.parseColor("#ffffff"));
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            public void afterTextChanged(Editable s) {
                nova.setNaziv(String.valueOf(naziv.getText()));
            }
        });

        iconDialog = new IconDialog();

        ikona.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i("ikona", "onClick: dosao ovde");
                iconDialog.setMenuVisibility(true);
                iconDialog.setShowSelectButton(true);
                iconDialog.setSelectedIcons(selectedIcons);
                iconDialog.show(getSupportFragmentManager(), "icon_dialog");
             //   nova.setId(""+selectedIcons[0].getId());

            }
        });

        dodajKategoriju.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new PostojanjeKategorije().execute(nova.getNaziv());

            }
            });
    }
    public void onIconDialogIconsSelected(Icon[] icons) {
        selectedIcons = icons;
        id =""+selectedIcons[0].getId();
        idIkone.setText(id);
        nova.setId(id);
    }
    public  void dajAlert(String s){
        AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
        builder1.setMessage(s);
        builder1.setCancelable(true);
        builder1.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                dialog.cancel();
            }
        });
        AlertDialog alert11 = builder1.create();
        alert11.show();
    }
}
