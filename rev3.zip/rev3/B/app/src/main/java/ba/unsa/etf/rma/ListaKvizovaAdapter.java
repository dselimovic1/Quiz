package ba.unsa.etf.rma;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.maltaisn.icondialog.IconHelper;
import com.maltaisn.icondialog.IconView;

import java.util.ArrayList;

import ba.unsa.etf.rma.aktivnosti.KvizoviAkt;
import ba.unsa.etf.rma.klase.Kviz;

public class ListaKvizovaAdapter extends BaseAdapter {
    private Activity activity;
    private ArrayList<Kviz> data=null;
    private static LayoutInflater inflater=null;
    public Resources res;
    public ListaKvizovaAdapter(Activity a, ArrayList<Kviz> d, Resources resLocal) {
        activity = a;
        data=d;
        res = resLocal;
        inflater = ( LayoutInflater )activity.
                getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }
    public int getCount() {
        if(data.size()<=0)
            return 1;
        return data.size();
    }

    public Object getItem(int position) {
        return position;
    }

    public long getItemId(int position) {
        return position;
    }

    public static class ViewHolder{
        public TextView ime;
        public IconView ikonica;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        final Context context = parent.getContext();
        View vi = convertView;
        final ViewHolder holder;

        if(convertView==null){

            vi = inflater.inflate(R.layout.element_liste, null);


            holder = new ViewHolder();
            holder.ime = (TextView) vi.findViewById(R.id.ime);
            holder.ikonica=(IconView) vi.findViewById(R.id.ikona);
            vi.setTag( holder );
        }
        else
            holder=(ViewHolder)vi.getTag();

        if(data.size()<=0)
        {
            holder.ime.setText(" ");

        }
        else
        {
            Kviz tempValues=null;
            tempValues = ( Kviz ) data.get( position );
            holder.ime.setText( tempValues.getNaziv() );

            final IconHelper helper=IconHelper.getInstance(context);

            final Kviz finalTempValues = tempValues;
            holder.ikonica.setIcon(Integer.parseInt(finalTempValues.getKategorija().getId()));
        }
        return vi;
    }
}
