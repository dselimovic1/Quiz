package ba.unsa.etf.rma;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class ListaOdgovoraAdapter extends BaseAdapter {
    private Activity activity;
    private ArrayList<String> data=null;
    private static LayoutInflater inflater=null;
    public Resources res;
    String tacan;

    public String getTacan() {
        return tacan;
    }

    public void setTacan(String tacan) {
        this.tacan = tacan;
    }

    public boolean isPostojiTacan() {
        return postojiTacan;
    }

    public void setPostojiTacan(boolean postojiTacan) {
        this.postojiTacan = postojiTacan;
    }

    private boolean postojiTacan=false;

    public ListaOdgovoraAdapter(Activity a, ArrayList<String> d, Resources resLocal) {
        activity = a;
        data=d;
        res = resLocal;
        inflater = ( LayoutInflater )activity.
                getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }

    public int getCount() {
        if(data.size()<=0)
            return 1;
        return data.size();
    }

    public Object getItem(int position) {
        return position;
    }

    public long getItemId(int position) {
        return position;
    }

    public static class ViewHolder{
        public TextView ime;
    }

    public View getView(int position, View convertView, ViewGroup parent) {

        View vi = convertView;
        ViewHolder holder;
        View view;

        if(convertView==null){

            vi = inflater.inflate(R.layout.element, null);

            holder = new ViewHolder();
            holder.ime =  vi.findViewById(R.id.element);
            vi.setTag( holder );
        }
        else
            holder=(ViewHolder)vi.getTag();

        if(data.size()<=0)
        {
            holder.ime.setText(" ");

        }
        else
        {
            String tempValues=null;
            tempValues = ( String ) data.get( position );
            holder.ime.setText( tempValues );
            if(postojiTacan && tempValues.equals(tacan)){
            vi.setBackgroundColor(Color.parseColor("#bcec4d"));
            } else{
                vi.setBackgroundColor(Color.parseColor("#ffffff"));
            }
        }
        return vi;
    }

}
