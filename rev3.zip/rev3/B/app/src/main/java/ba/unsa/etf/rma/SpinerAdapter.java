package ba.unsa.etf.rma;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.SpinnerAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import ba.unsa.etf.rma.aktivnosti.KvizoviAkt;
import ba.unsa.etf.rma.klase.Kategorija;

public class SpinerAdapter extends BaseAdapter {
    private Activity activity;
    private ArrayList<Kategorija> data;
    private static LayoutInflater inflater;
    public Resources res;
    public SpinerAdapter(Activity a, ArrayList<Kategorija> kat, Resources resLocal) {
        activity = a;
        data=kat;
        res = resLocal;
        /*ArrayList<String> nazivi= new ArrayList<>();
        for (int i = 0; i <kat.size() ; i++) {
            nazivi.add(kat.get(i).getNaziv());
        }*/
        inflater = ( LayoutInflater )activity.
                getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }

   public int getCount() {
       return (data == null) ? 0 : data.size();
   }

    public Object getItem(int position) {
        return position;
    }

    public long getItemId(int position) {
        return position;
    }

    public static class ViewHolder{
        public TextView kategorija;
    }

    public View getView(int position, View convertView, ViewGroup parent) {

        View vi = convertView;
        ViewHolder holder;

        if(convertView==null){

            vi = inflater.inflate(R.layout.element, null);


            holder = new ViewHolder();
            holder.kategorija = (TextView) vi.findViewById(R.id.element);
            vi.setTag( holder );
        }
        else
            holder=(ViewHolder)vi.getTag();

        if(data.size()<=0)
        {
            //holder.kategorija.setText(" ");
            Kategorija tempValues=null;
            tempValues = ( Kategorija ) data.get( position );
            holder.kategorija.setText( tempValues.getNaziv() );
        }
        else
        {
            Kategorija tempValues=null;
            tempValues = ( Kategorija ) data.get( position );
            holder.kategorija.setText( tempValues.getNaziv() );
        }
        return vi;
    }

}
