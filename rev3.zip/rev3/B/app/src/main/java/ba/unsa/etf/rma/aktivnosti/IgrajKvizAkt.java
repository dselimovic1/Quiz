package ba.unsa.etf.rma.aktivnosti;

import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Timer;
import java.util.TimerTask;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.fragmenti.InformacijeFrag;
import ba.unsa.etf.rma.fragmenti.PitanjeFrag;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;

public class IgrajKvizAkt extends AppCompatActivity implements PitanjeFrag.OnItemClick {
    private Kviz k;
    int br=0, max;
    private double procenat;
    private int brojTacnih=0;
    ArrayList<Pitanje> izmijesanaPitanja=new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.igranje_kviza);

        k= (Kviz) getIntent().getSerializableExtra("kviz");
        max=k.getPitanja().size();
        izmijesanaPitanja.addAll(k.getPitanja());
        Collections.shuffle(izmijesanaPitanja);

        InformacijeFrag informacijeFrag=new InformacijeFrag();
        PitanjeFrag pitanjeFrag = new PitanjeFrag();

        Bundle argumentiP= new Bundle();
        if(br<max) {
            argumentiP.putSerializable("pitanje", izmijesanaPitanja.get(br));
        }else{
            argumentiP.putSerializable("pitanje", new Pitanje("Kviz je završen!","Kviz je završen!","", new ArrayList<String>()));
        }
        pitanjeFrag.setArguments(argumentiP);

        Bundle argumentiInfo= new Bundle();
        argumentiInfo.putSerializable("kviz", k);
        argumentiInfo.putString("procenat", "0");
        argumentiInfo.putString("brTacnih", "0");
       if(k.getPitanja().size()!=0) argumentiInfo.putString("preostalo", ""+(k.getPitanja().size()-1));
        else argumentiInfo.putString("preostalo", ""+k.getPitanja().size());
        informacijeFrag.setArguments(argumentiInfo);

        FragmentManager fm=getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        ft.replace(R.id.informacijePlace,informacijeFrag);
        FragmentManager fm2=getSupportFragmentManager();
        FragmentTransaction ft2 = fm2.beginTransaction();
        ft2.replace(R.id.pitanjePlace, pitanjeFrag);

        ft.commit();
        ft2.commit();

    }

    @Override
    public void onItemClicked(int pos,boolean tacan) {
        int delay =2000;// in ms
        if(tacan) brojTacnih++;
        br++;
         procenat=(double)brojTacnih/br;
         procenat*=100;

        Timer timer = new Timer();
        timer.schedule( new TimerTask(){
            public void run() {
               try{
                   PitanjeFrag novi=new PitanjeFrag();
                Bundle argumentiP= new Bundle();
                if(br<max) {
                    argumentiP.putSerializable("pitanje",izmijesanaPitanja.get(br));
                }else{
                    argumentiP.putSerializable("pitanje", new Pitanje("Kviz je završen!","Kviz je završen!","", new ArrayList<String>()));
                }
                novi.setArguments(argumentiP);
                FragmentManager fm2=getSupportFragmentManager();
                FragmentTransaction ft2 = fm2.beginTransaction();
                ft2.replace(R.id.pitanjePlace, novi);

                InformacijeFrag noveInfo=new InformacijeFrag();
                Bundle argumentiInfo= new Bundle();
                argumentiInfo.putSerializable("kviz", k);
                argumentiInfo.putString("procenat", ""+String.format("%.2f", procenat));
                argumentiInfo.putString("brTacnih", ""+brojTacnih);
                if(k.getPitanja().size()-br>=1) argumentiInfo.putString("preostalo", ""+(k.getPitanja().size()-br-1));
                else argumentiInfo.putString("preostalo", ""+(k.getPitanja().size()-br));
                noveInfo.setArguments(argumentiInfo);
                FragmentManager fm=getSupportFragmentManager();
                FragmentTransaction ft = fm.beginTransaction();
                ft.replace(R.id.informacijePlace, noveInfo);

                ft.commit();
                ft2.commit();
            }catch(Exception e){
                finish();
            }}
        }, delay);
    }
}
