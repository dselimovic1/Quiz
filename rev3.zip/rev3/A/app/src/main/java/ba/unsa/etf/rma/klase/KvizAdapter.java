package ba.unsa.etf.rma.klase;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;

public class KvizAdapter extends ArrayAdapter<Kviz> {

    public KvizAdapter(@NonNull Context context, ArrayList<Kviz> kvizovi) {
        super(context, 0, kvizovi);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        return initView(position, convertView, parent);
    }

    @Override
    public View getDropDownView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        return initView(position, convertView, parent);
    }

    private View initView(int position, View convertView, ViewGroup parent){

        if(convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.kviz_u_listi,
                    parent, false);
        }

        ImageView ikona = convertView.findViewById(R.id.ikonakviza);
        TextView naziv = convertView.findViewById(R.id.nazivkviza);

        Kviz kviz = getItem(position);

        if(kviz.getNaziv().equalsIgnoreCase("Dodaj kviz")){
            ikona.setImageResource(R.drawable.plus);
        }
        naziv.setText(kviz.getNaziv());

        return convertView;
    }
}
