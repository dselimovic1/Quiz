package ba.unsa.etf.rma.aktivnosti;

import android.app.AlertDialog;
import android.app.FragmentManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.text.InputType;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.fragmenti.PitanjeFrag;
import ba.unsa.etf.rma.fragmenti.RanglistaFrag;
import ba.unsa.etf.rma.klase.DataWrapper;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;
import ba.unsa.etf.rma.klase.RangLista;

public class IgrajKvizAkt extends AppCompatActivity implements PitanjeFrag.OnFragmentInteractionListener2, IDohvatiRanglisteDone, ba.unsa.etf.rma.fragmenti.RanglistaFrag.OnFragmentInteractionListener2 {
    static int indeks=0, tacniOdgovori=0, preostalaPitanja=0, indeksTacnogOdgovora=0;
    String JSONRangliste="";



    public ArrayList<RangLista> parsirajRangliste(String json)
    {
        ArrayList<RangLista> list = new ArrayList<RangLista>();
        try {
            int pozicija = 0, procenatTacnih=0;
            String qName = "", imeIgraca="";
            JSONObject object = new JSONObject(json);
            JSONArray dokumenti = object.getJSONArray("documents");
            for (int j = 0; j < dokumenti.length(); j++) {
                ArrayList<String> answerList = new ArrayList<String>();
                JSONObject jObject = dokumenti.getJSONObject(j);
                JSONObject fields = jObject.getJSONObject("fields");
                if (fields.has("nazivKviza") && fields.getJSONObject("nazivKviza").has("stringValue")) {
                    qName = fields.getJSONObject("nazivKviza").getString("stringValue");
                }
                JSONObject mapa1 = fields.getJSONObject("lista");
                JSONObject polja = mapa1.getJSONObject("mapValue");
                JSONObject fields2 = polja.getJSONObject("fields");
                if (fields2.has("kljuc") && fields2.getJSONObject("kljuc").has("integerValue")) {
                    pozicija = fields2.getJSONObject("kljuc").getInt("integerValue");
                }
                JSONObject vrijednost = fields2.getJSONObject("vrijednost");
                JSONObject polja2 = vrijednost.getJSONObject("mapValue");
                JSONObject fields3 = polja2.getJSONObject("fields");
                if (fields3.has("procenatTacnihO") && fields3.getJSONObject("procenatTacnihO").has("integerValue")) {
                    procenatTacnih = fields3.getJSONObject("procenatTacnihO").getInt("integerValue");
                }
                if (fields3.has("imeIgraca") && fields3.getJSONObject("imeIgraca").has("stringValue")) {
                    imeIgraca = fields3.getJSONObject("imeIgraca").getString("stringValue");
                }
                list.add(new RangLista(imeIgraca, pozicija, qName, procenatTacnih));
            }
        }
        catch(JSONException e)
        {
            //something
        }
        return list;
    }



    @Override
    public void gotovoRangliste(String json) {
        JSONRangliste=json;
    }

    public class DohvatiRanglisteTask extends AsyncTask<String,Void, String> {
        String jsonString = "";

        public String dajStringBa() {
            return jsonString;
        }

        @Override
        protected String doInBackground(String... strings) {
            GoogleCredential credentials;
            try {
                InputStream secretStream = getResources().openRawResource(R.raw.secret);
                credentials = GoogleCredential.fromStream(secretStream).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();
                String TOKEN = credentials.getAccessToken();
                String url = "https://firestore.googleapis.com/v1beta1/projects/spirala3-rma-17324-241419/databases/(default)/documents/Rangliste?access_token=";
                URL urlObj = new URL(url + URLEncoder.encode(TOKEN, "utf-8"));
                HttpURLConnection conn = (HttpURLConnection) urlObj.openConnection();
                //  conn.setDoOutput(true);
                conn.setRequestMethod("GET");
                // conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("Accept", "application/json");

                int code = conn.getResponseCode();
                InputStream odgovor = conn.getInputStream();
                try (BufferedReader br = new BufferedReader(
                        new InputStreamReader(odgovor, "utf-8"))) {
                    StringBuffer response = new StringBuffer();
                    String responseLine = null;
                    while ((responseLine = br.readLine()) != null) {
                        response.append(responseLine.trim());
                    }
                    br.close();
                    jsonString = response.toString();
                    poziv.gotovoRangliste(jsonString);
                    //  Log.d("ODGOVOR", response.toString());
                    return response.toString();
                }

            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        }


        private IDohvatiRanglisteDone poziv;

        public DohvatiRanglisteTask(IDohvatiRanglisteDone p) {
            poziv = p;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(jsonString);
            poziv.gotovoRangliste(jsonString);
            dajStringBa();
        }
    }










    protected void setFragment(Fragment fragment) { //promjena na ranglistu i nazad
        android.support.v4.app.FragmentTransaction t = getSupportFragmentManager().beginTransaction();
        t.replace(R.id.pitanjePlace, fragment);
        t.commit();
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_igraj_kviz_akt);
        final ArrayList<Kviz> kvizovi;
        final ArrayList<Kategorija> kategorije;
        final ArrayList<Pitanje> pitanja;
        final int pozicija;
        /*InputStream is = getResources().openRawResource(android.R.raw.secret);
        GoogleCredential credentials = GoogleCredential.fromStream(is).
                createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
        credentials.refreshToken();
        String TOKEN = credentials.getAccessToken();*/
        DataWrapper dw2 = (DataWrapper) getIntent().getSerializableExtra("data");
            kvizovi = dw2.getKvizovi();
            kategorije = dw2.getKategorije();
            pitanja = dw2.getPitanja();
            pozicija = dw2.getLokacija();
        FragmentManager fm = getFragmentManager();
       /* Fragment fInf = fm.findFragmentById(R.id.informacijePlace);
        //saljemo u ba.unsa.etf.rma.fragmenti.InformacijeFrag
        {
            Intent dodavanje = new Intent(IgrajKvizAkt.this, ba.unsa.etf.rma.fragmenti.InformacijeFrag.class);
            dodavanje.putExtra("data", new DataWrapper(kvizovi, kategorije_list, pitanja, 1));
            startActivity(dodavanje);
        }*/

        final ListView mojaLista = (ListView) findViewById(R.id.odgovoriPitanja);
       final Kviz k = kvizovi.get(pozicija);
        final ArrayList<String> odgovoriZaListu = new ArrayList<String>();
       final ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, odgovoriZaListu);
        mojaLista.setAdapter(adapter);

        /*final ListView rangLista = (ListView) findViewById(R.id.lvRanglista);
        final ArrayList<RangLista> ranking=new ArrayList<>();
        ranking.addAll(parsirajRangliste(JSONRangliste));
       final CustomAdapterRangliste rangAdapter = new CustomAdapterRangliste(this, R.layout.rangliste, ranking);
        rangAdapter.setNotifyOnChange(true);
        rangLista.setAdapter(rangAdapter);*/

        /*final ArrayAdapter<RangLista>  adaptercina = new ArrayAdapter<>(this, R.layout.rangliste, ranking);
        rangLista.setAdapter(adaptercina);*/

        TextView nazivKviza = (TextView) findViewById(R.id.infNazivKviza);
        nazivKviza.setText(k.getNaziv());
        final TextView brTacnih = (TextView) findViewById(R.id.infBrojTacnihPitanja);
        brTacnih.setText("0");
        final TextView procenatTacnih = (TextView) findViewById(R.id.infProcenatTacni);
        procenatTacnih.setText("0%");
        final TextView brPreostalih = (TextView) findViewById(R.id.infBrojPreostalihPitanja);
        //promijesa raspored pitanja
        k.setPitanja(k.dajRandomPitanja());
        for (int i = 0; i < k.getPitanja().size(); i++)
            if (k.getPitanja().get(i).getNaziv().equals("Dodaj Pitanje")) k.getPitanja().remove(i);
        if (k.getPitanja().size()>0)
        {
            TextView text = (TextView) findViewById(R.id.tekstPitanja);
            text.setText(k.getPitanja().get(0).getNaziv());
            odgovoriZaListu.addAll(k.getPitanja().get(0).getOdgovori());
            k.getPitanja().get(0).setPostavljenoPitanje(true);
            adapter.notifyDataSetChanged();
            preostalaPitanja=k.getPitanja().size();
            brPreostalih.setText("" + k.getPitanja().size());
        }
        else
        {
            preostalaPitanja=0;
            brPreostalih.setText("0");
            TextView text = (TextView) findViewById(R.id.tekstPitanja);
            text.setText("Kviz je završen!");
            adapter.notifyDataSetChanged();
        }
        final Button zavrsiKviz = (Button) findViewById(R.id.btnKraj);
        zavrsiKviz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                odgovoriZaListu.clear();
               TextView  text = (TextView) findViewById(R.id.tekstPitanja);
                text.setText("Kviz je završen!");
                adapter.notifyDataSetChanged();
                Intent krajKviza = new Intent(IgrajKvizAkt.this, KvizoviAkt.class);
                krajKviza.putExtra("data", new DataWrapper(kvizovi, kategorije, pitanja, 0));
                startActivity(krajKviza);
            }
        });
        //spasavamo randomizirana pitanja
        final ArrayList<Pitanje> kloniranaPitanja = (ArrayList<Pitanje>) k.getPitanja().clone();
         indeks=0;
         tacniOdgovori=0;


         //FLAG
        mojaLista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterac, View view, final int position, long arg) {
                //promijesa raspored pitanja
               // k.dajRandomPitanja();
               // indeks=0;
                indeksTacnogOdgovora=0;


                    //Random raspored odgovora uz funkciju s prve spirale
                    final TextView  text = (TextView) findViewById(R.id.tekstPitanja);
               /* if (indeks!=0) {
                    odgovoriZaListu.clear();
                    odgovoriZaListu.addAll(kloniranaPitanja.get(indeks).getOdgovori());
                }*/
                        //indeks++;
                        adapter.notifyDataSetChanged();
                    //na kraju ovo, cekamo 2 sekunde
                    kloniranaPitanja.get(indeks).setPostavljenoPitanje(true);
                    mojaLista.setEnabled(false);
                    mojaLista.setClickable(false);
                adapter.notifyDataSetChanged();
                    brPreostalih.setText(String.valueOf(--preostalaPitanja));
               /* Toast.makeText(getApplicationContext(), "Odgovor: " + odgovoriZaListu.get(position),
                        Toast.LENGTH_SHORT).show();
                Toast.makeText(getApplicationContext(), "Tacan: " + kloniranaPitanja.get(indeks-1).getTacan(),
                        Toast.LENGTH_SHORT).show();*/
               String tacanOdgovor="";
               for (int i = 0; i < odgovoriZaListu.size(); i++)
                   if (odgovoriZaListu.get(i).equals(kloniranaPitanja.get(indeks).getTacan()))
                       indeksTacnogOdgovora=i;

                if (position==indeksTacnogOdgovora)
                {
                    if (mojaLista.getChildAt(position)!=null)
                    mojaLista.getChildAt(position).setBackgroundColor(getResources().getColor(R.color.zelena));
                    tacniOdgovori++;
                    brTacnih.setText(String.valueOf(tacniOdgovori));
                    procenatTacnih.setText(String.valueOf(zaokruzi((100.0*tacniOdgovori)/(k.getPitanja().size()-preostalaPitanja)))+ "%");
                }
                    else
                        {
                            if (mojaLista.getChildAt(indeksTacnogOdgovora)!=null)
                            mojaLista.getChildAt(indeksTacnogOdgovora).setBackgroundColor(getResources().getColor(R.color.zelena));
                            if (mojaLista.getChildAt(position)!=null)
                            mojaLista.getChildAt(position).setBackgroundColor(getResources().getColor(R.color.crvena));
                            procenatTacnih.setText(String.valueOf(zaokruzi((100.0*tacniOdgovori)/(k.getPitanja().size()-preostalaPitanja)))+ "%");
                        }
                    final int pozicijaPrenos=position;
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        int brojPitanja = kloniranaPitanja.size();
                        public void run() {

                            if (mojaLista.getChildAt(pozicijaPrenos)!=null)
                            mojaLista.getChildAt(pozicijaPrenos).setBackgroundColor(Color.TRANSPARENT);
                            if (mojaLista.getChildAt(indeksTacnogOdgovora)!=null)
                            mojaLista.getChildAt(indeksTacnogOdgovora).setBackgroundColor(Color.TRANSPARENT);
                            if (indeks+1<brojPitanja) {
                                indeks++;
                                    text.setText(kloniranaPitanja.get(indeks).getNaziv());
                                    odgovoriZaListu.clear();
                                    odgovoriZaListu.addAll(kloniranaPitanja.get(indeks).dajRandomOdgovore());
                                    adapter.notifyDataSetChanged();
                            }
                            else{
                                odgovoriZaListu.clear();
                                text.setText("Kviz je završen!");
                                adapter.notifyDataSetChanged();
                                ba.unsa.etf.rma.fragmenti.RanglistaFrag fragment = new RanglistaFrag();
                                setFragment(fragment);
                                DohvatiRanglisteTask dpt = new DohvatiRanglisteTask(IgrajKvizAkt.this);
                                unesiImeZaRL();
                                try {
                                    dpt.execute().get(); //get?
                                } catch (ExecutionException e) {
                                    e.printStackTrace();
                                } catch (InterruptedException e) {
                                    e.printStackTrace();
                                }
                                //FLAG
                                // ranking.addAll(parsirajRangliste(JSONRangliste));
                            }
                            mojaLista.setEnabled(true);
                            mojaLista.setClickable(true);
                        }
                    }, 2000);
            }
        });
    }
    String zapamtiUnos="";
    void unesiImeZaRL()
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Unesite ime: ");

        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT );
        builder.setView(input);

        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                zapamtiUnos = input.getText().toString();
            }
        });
        builder.setNegativeButton("Otkaži", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        builder.show();
    }
    double zaokruzi(double d)
    {
        DecimalFormat twoDForm = new DecimalFormat("#.##");
        return Double.valueOf(twoDForm.format(d));
    }
    @Override
    public void onAttachFragment(Fragment fragment) {
        if (fragment instanceof PitanjeFrag) {
            PitanjeFrag frago = (PitanjeFrag) fragment;
            frago.postaviListener(this);
        }
        if (fragment instanceof RanglistaFrag) {
            RanglistaFrag frago = (RanglistaFrag) fragment;
            frago.postaviListener(this);
        }
    }

    @Override
    public void promjenaKviza()
    {
    }
    @Override
    public void azuriranjeRangliste()
    {
    }
}
