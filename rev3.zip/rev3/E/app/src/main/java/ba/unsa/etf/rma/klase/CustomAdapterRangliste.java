package ba.unsa.etf.rma.klase;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;

public class CustomAdapterRangliste extends ArrayAdapter<RangLista> {
    private Context mContext;
    private int resources;
    private ArrayList<RangLista> rang;

    public CustomAdapterRangliste(Context context, int res, ArrayList<RangLista> rang) {
        super(context, res, rang);
        mContext = context;
        resources = res;
        this.rang = rang;
    }



    public View getView(int position, View convertView, ViewGroup parent) {

        if (convertView==null) {
            LayoutInflater inflater = LayoutInflater.from(mContext);
            convertView = inflater.inflate(R.layout.rangliste, parent, false);
        }
         //View view = inflater.inflate(R.layout.activity_igraj_kviz_akt, null);

        TextView textView = (TextView) convertView.findViewById(R.id.etRangliste);
        final RangLista rangIgraca = rang.get(position);
        textView.setText(rangIgraca.toString());
        return convertView;
    }
}
