package ba.unsa.etf.rma.aktivnosti;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.Spinner;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;
import com.maltaisn.icondialog.IconHelper;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.fragmenti.DetailFrag;
import ba.unsa.etf.rma.fragmenti.ListaFrag;
import ba.unsa.etf.rma.klase.CustomAdapterGrid;
import ba.unsa.etf.rma.klase.CustomAdapterKviz;
import ba.unsa.etf.rma.klase.DataWrapper;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;

public class KvizoviAkt extends AppCompatActivity implements DetailFrag.OnFragmentInteractionListener2, ListaFrag.OnFragmentInteractionListener2, ba.unsa.etf.rma.fragmenti.RanglistaFrag.OnFragmentInteractionListener2, IDohvatiPitanjeDone, IDohvatiKvizDone, IDohvatiKategorijeDone {
    boolean prviPutUcitan=true;
     ArrayList<Kviz> kvizovi;
    ArrayList<Kategorija> kategorije;
     ArrayList<Pitanje> pitanja;
     String JSONParsiranje="";
     String JSONKat="";
//daj logiku




    String JSONKvizovi="";
    final int READ_REQ = 42;

    @Override
    public void gotovo(String json) {
        JSONKvizovi=json;
    }
    @Override
    public void gotovoKviz(String json) {
        JSONParsiranje=json;
    }
    @Override
    public void gotovoKat(String json) {JSONKat=json;}
    public ArrayList<Pitanje> parsirajPitanja(String json)
    {
        ArrayList<Pitanje> list = new ArrayList<Pitanje>();
        try {
            int indeks = 0;
            String qName = "";
            JSONObject object = new JSONObject(json);
            JSONArray dokumenti = object.getJSONArray("documents");
            for (int j = 0; j < dokumenti.length(); j++) {
                ArrayList<String> answerList = new ArrayList<String>();
                JSONObject jObject = dokumenti.getJSONObject(j);
                JSONObject fields = jObject.getJSONObject("fields");
                if (fields.has("indexTacnog") && fields.getJSONObject("indexTacnog").has("integerValue")) {
                    indeks = fields.getJSONObject("indexTacnog").getInt("integerValue");
                }
                if (fields.has("naziv") && fields.getJSONObject("naziv").has("stringValue")) {
                    qName = fields.getJSONObject("naziv").getString("stringValue");
                }
                JSONArray answerArray = fields.getJSONObject("odgovori").getJSONObject("arrayValue").getJSONArray("values");
                for (int i = 0; i < answerArray.length(); i++) {
                    try {
                        String answer= answerArray.getJSONObject(i).getString("stringValue");
                        answerList.add(answer);
                    } catch (JSONException e) {

                        Log.d("OOPS", qName);
                    }
                }
                list.add(new Pitanje(qName, qName, answerList, answerList.get(indeks), 0));
            }
        }
        catch(JSONException e)
        {
            //something
        }
        return list;
    }




    public class DohvatiKvizTask extends AsyncTask<String,Void, String> {
        String jsonString = "";

        public String dajStringBa() {
            return jsonString;
        }

        @Override
        protected String doInBackground(String... strings) {
            GoogleCredential credentials;
            try {
                InputStream secretStream = getResources().openRawResource(R.raw.secret);
                credentials = GoogleCredential.fromStream(secretStream).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();
                String TOKEN = credentials.getAccessToken();
                String url = "https://firestore.googleapis.com/v1beta1/projects/spirala3-rma-17324-241419/databases/(default)/documents/Kvizovi?access_token=";
                URL urlObj = new URL(url + URLEncoder.encode(TOKEN, "utf-8"));
                HttpURLConnection conn = (HttpURLConnection) urlObj.openConnection();
                //  conn.setDoOutput(true);
                conn.setRequestMethod("GET");
                // conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("Accept", "application/json");

                int code = conn.getResponseCode();
                InputStream odgovor = conn.getInputStream();
                try (BufferedReader br = new BufferedReader(
                        new InputStreamReader(odgovor, "utf-8"))) {
                    StringBuffer response = new StringBuffer();
                    String responseLine = null;
                    while ((responseLine = br.readLine()) != null) {
                        response.append(responseLine.trim());
                    }
                    br.close();
                    jsonString = response.toString();
                    poziv.gotovoKviz(jsonString);
                    //  Log.d("ODGOVOR", response.toString());
                    return response.toString();
                }

            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        }


        private IDohvatiKvizDone poziv;

        public DohvatiKvizTask(IDohvatiKvizDone p) {
            poziv = p;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(jsonString);
            poziv.gotovoKviz(jsonString);
            dajStringBa();
        }
    }

    public ArrayList<Kategorija> parsirajKategorije(String json)
    {
        ArrayList<Kategorija> list = new ArrayList<Kategorija>();
        try {
            int indeks = 0;
            String qName = "";
            JSONObject object = new JSONObject(json);
            JSONArray dokumenti = object.getJSONArray("documents");
            for (int j = 0; j < dokumenti.length(); j++) {
                ArrayList<String> answerList = new ArrayList<String>();
                JSONObject jObject = dokumenti.getJSONObject(j);
                JSONObject fields = jObject.getJSONObject("fields");
                if (fields.has("idIkonice") && fields.getJSONObject("idIkonice").has("integerValue")) {
                    indeks = fields.getJSONObject("idIkonice").getInt("integerValue");
                }
                if (fields.has("naziv") && fields.getJSONObject("naziv").has("stringValue")) {
                    qName = fields.getJSONObject("naziv").getString("stringValue");
                }
                list.add(new Kategorija(qName, indeks));
            }
        }
        catch(JSONException e)
        {
            //something
        }
        return list;
    }

    public class DohvatiKategorijeTask extends AsyncTask<String,Void, String> {
        String jsonString = "";

        public String dajStringBa() {
            return jsonString;
        }

        @Override
        protected String doInBackground(String... strings) {
            GoogleCredential credentials;
            try {
                InputStream secretStream = getResources().openRawResource(R.raw.secret);
                credentials = GoogleCredential.fromStream(secretStream).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();
                String TOKEN = credentials.getAccessToken();
                String url = "https://firestore.googleapis.com/v1beta1/projects/spirala3-rma-17324-241419/databases/(default)/documents/Kategorije?access_token=";
                URL urlObj = new URL(url + URLEncoder.encode(TOKEN, "utf-8"));
                HttpURLConnection conn = (HttpURLConnection) urlObj.openConnection();
                //  conn.setDoOutput(true);
                conn.setRequestMethod("GET");
                // conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("Accept", "application/json");

                int code = conn.getResponseCode();
                InputStream odgovor = conn.getInputStream();
                try (BufferedReader br = new BufferedReader(
                        new InputStreamReader(odgovor, "utf-8"))) {
                    StringBuffer response = new StringBuffer();
                    String responseLine = null;
                    while ((responseLine = br.readLine()) != null) {
                        response.append(responseLine.trim());
                    }
                    br.close();
                    jsonString = response.toString();
                    poziv.gotovoKat(jsonString);
                    //  Log.d("ODGOVOR", response.toString());
                    return response.toString();
                }

            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        }


        private IDohvatiKategorijeDone poziv;

        public DohvatiKategorijeTask(IDohvatiKategorijeDone p) {
            poziv = p;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(jsonString);
            poziv.gotovoKat(jsonString);
            dajStringBa();
        }
    }




    public class DohvatiPitanjeTask extends AsyncTask<String,Void, String> {
        String jsonString = "";

        public String dajStringBa() {
            return jsonString;
        }

        @Override
        protected String doInBackground(String... strings) {
            GoogleCredential credentials;
            try {
                InputStream secretStream = getResources().openRawResource(R.raw.secret);
                credentials = GoogleCredential.fromStream(secretStream).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();
                String TOKEN = credentials.getAccessToken();
                String url = "https://firestore.googleapis.com/v1beta1/projects/spirala3-rma-17324-241419/databases/(default)/documents/Pitanja?access_token=";
                URL urlObj = new URL(url + URLEncoder.encode(TOKEN, "utf-8"));
                HttpURLConnection conn = (HttpURLConnection) urlObj.openConnection();
                //  conn.setDoOutput(true);
                conn.setRequestMethod("GET");
                // conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("Accept", "application/json");

                int code = conn.getResponseCode();
                InputStream odgovor = conn.getInputStream();
                try (BufferedReader br = new BufferedReader(
                        new InputStreamReader(odgovor, "utf-8"))) {
                    StringBuffer response = new StringBuffer();
                    String responseLine = null;
                    while ((responseLine = br.readLine()) != null) {
                        response.append(responseLine.trim());
                    }
                    br.close();
                    jsonString = response.toString();
                    poziv.gotovo(jsonString);
                    //  Log.d("ODGOVOR", response.toString());
                    return response.toString();
                }

            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        }


        private IDohvatiPitanjeDone poziv;

        public DohvatiPitanjeTask(IDohvatiPitanjeDone p) {
            poziv = p;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(jsonString);
            poziv.gotovo(jsonString);
            dajStringBa();
        }
    }





    public ArrayList<Kviz> parsirajKvizove(String json)
    {
        DohvatiPitanjeTask dpt = new DohvatiPitanjeTask(KvizoviAkt.this);
        try {
            dpt.execute().get(); //get?
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        ArrayList<Pitanje> svaPitanja = parsirajPitanja(JSONKvizovi);
        ArrayList<Kviz> list = new ArrayList<Kviz>();
        try {
            String idKat="";
            String qName = "";
            String ID="";
            JSONObject object = new JSONObject(json);
            JSONArray dokumenti = object.getJSONArray("documents");
            for (int j = 0; j < dokumenti.length(); j++) {
                ArrayList<Pitanje> answerList = new ArrayList<Pitanje>();
                JSONObject jObject = dokumenti.getJSONObject(j);
               /* JSONObject naziviDokumenata = jObject.getJSONObject("name");
                ID=naziviDokumenata.getString("name");*/
                JSONObject fields = jObject.getJSONObject("fields");
                if (fields.has("idKategorije") && fields.getJSONObject("idKategorije").has("stringValue")) {
                    idKat = fields.getJSONObject("idKategorije").getString("stringValue");
                }
                if (fields.has("naziv") && fields.getJSONObject("naziv").has("stringValue")) {
                    qName = fields.getJSONObject("naziv").getString("stringValue");
                }
                JSONArray answerArray = fields.getJSONObject("pitanja").getJSONObject("arrayValue").getJSONArray("values");
                for (int i = 0; i < answerArray.length(); i++) {
                    try {
                        String answer= answerArray.getJSONObject(i).getString("stringValue");
                        for (int k = 0; k < svaPitanja.size(); k++) if (svaPitanja.get(k).getNaziv().equals(answer))
                            answerList.add(svaPitanja.get(k));
                    } catch (JSONException e) {

                        Log.d("OOPS", qName);
                    }
                }
                Kategorija kategorijaKviza = new Kategorija("nesto", R.drawable.ic_launcher_background);
                for (int i = 0; i < kategorije.size(); i++) if (kategorije.get(i).getId().equals(idKat))
                    kategorijaKviza=kategorije.get(i);
                Kviz kv=new Kviz(qName, answerList, kategorijaKviza, kategorijaKviza.getSlikaKategorije());
                kv.setIdUBazi(ID);
                list.add(kv);
            }
        }
        catch(JSONException e)
        {
            //something
        }
        return list;
    }


    public class KreirajDokumentTask extends AsyncTask<String,Void, Void> {
        @Override
        protected Void doInBackground(String... strings)
        {
            GoogleCredential credentials;
            try {
                InputStream secretStream = getResources().openRawResource(R.raw.secret);
                credentials = GoogleCredential.fromStream(secretStream).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));

                credentials.refreshToken();
                String TOKEN = credentials.getAccessToken();
                Log.d("TOKEN", TOKEN);
            }
            catch(IOException e)
            {
                e.printStackTrace();
            }
            return null;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_main);
        final IconHelper iconHelper = IconHelper.getInstance(getApplicationContext());
        DataWrapper dw2 = (DataWrapper) getIntent().getSerializableExtra("data");
        if (dw2 != null) {
            kvizovi = dw2.getKvizovi();
            kategorije = dw2.getKategorije();
            pitanja = dw2.getPitanja();
        } else {
            kvizovi = new ArrayList<Kviz>();
            kategorije = new ArrayList<Kategorija>();
            pitanja = new ArrayList<Pitanje>();
            //ucitavanje kategorija u spinner
            kategorije.add(new Kategorija("Sve", R.mipmap.ic_launcher));
            //FLAG
            DohvatiKvizTask dpt = new DohvatiKvizTask(KvizoviAkt.this);
            try {
                dpt.execute().get(); //get?
            } catch (ExecutionException e) {
                e.printStackTrace();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            DohvatiKategorijeTask dpt2 = new DohvatiKategorijeTask(KvizoviAkt.this);
            try {
                dpt2.execute().get(); //get?
            } catch (ExecutionException e2) {
                e2.printStackTrace();
            } catch (InterruptedException e2) {
                e2.printStackTrace();
            }
            //dodavanje kvizova za početni ekran
         /*   for (int i = 1; i < 5; i++) {
                kvizovi.add(new Kviz("Kviz " + i, R.mipmap.ic_launcher));
            }*/
            //kvizovi.add(new Kviz("Dodaj Kviz", R.drawable.ic_launcher_background));
        }
        kvizovi.addAll(parsirajKvizove(JSONParsiranje));
        kategorije.addAll(parsirajKategorije(JSONKat));
        final ArrayList<Kviz> kopijaKvizovi = (ArrayList<Kviz>) kvizovi.clone();
        // kopijaKvizovi.add(new Kviz("Dodaj Kviz", R.drawable.ic_launcher_background));
        Configuration config = KvizoviAkt.this.getResources().getConfiguration();
        if (config.screenWidthDp >= 550) {
            // siroki layout
            final ListView listaKat = (ListView) findViewById(R.id.listaKategorija);
            final ArrayAdapter<Kategorija> dataAdapter = new ArrayAdapter<Kategorija>(this,
                   R.layout.kategorije_list, kategorije);
            listaKat.setAdapter(dataAdapter);
            final GridView gridView = (GridView)findViewById(R.id.gridKvizovi);
            final ArrayList<Kviz> klonKvizovi = (ArrayList<Kviz>) kvizovi.clone();
            klonKvizovi.add(new Kviz("Dodaj Kviz", R.drawable.ic_launcher_background));
            final CustomAdapterGrid kvizAdapter = new CustomAdapterGrid(this, R.layout.grid_kviz, klonKvizovi);
            gridView.setAdapter(kvizAdapter);
            /*treba jos da se mijenjaju kvizovi onSelectedItem
            malo povecati font naziva kviza i slike, probati autofit sa one stranice
             */
            listaKat.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapter, View view, int position, long arg) {
                    klonKvizovi.clear();
                    for (int i = 0; i <kvizovi.size();i++)
                        if (kvizovi.get(i).getKategorija().getNaziv().equals(kategorije.get(position).getNaziv()))
                        klonKvizovi.add(kvizovi.get(i));
                        //provjera ima li polje za dodavanje pitanja
                    {
                        boolean ima = false;
                        for (int i = 0; i < klonKvizovi.size(); i++)
                            if (klonKvizovi.get(i).getNaziv().equals("Dodaj Kviz")) ima = true;
                        if (!ima)
                            klonKvizovi.add(new Kviz("Dodaj Kviz", R.drawable.ic_launcher_background));
                    }
                    kvizAdapter.notifyDataSetChanged();
                    dataAdapter.notifyDataSetChanged();
                }
        });

            //KvizoviKlik


            gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapter, View view, int position, long arg) {
                    int pozicijaDodavanja = gridView.getLastVisiblePosition(); //uzima poziciju posljednjeg elementa (onog za dodavanje kvizova)
                    if (position == pozicijaDodavanja) { //ako klikne kratkim klikom na dodajKviz treba mu se i otvoriti DodajKvizAkt
                        Intent dodavanje = new Intent(KvizoviAkt.this, DodajKvizAkt.class);
                        dodavanje.putExtra("data", new DataWrapper(kvizovi, kategorije, pitanja, -1));
                        startActivity(dodavanje);
                    } else { //otvori IgrajKviz
                        Intent dodavanje = new Intent(KvizoviAkt.this, IgrajKvizAkt.class);
                        dodavanje.putExtra("data", new DataWrapper(kvizovi, kategorije, kvizovi.get(position).getPitanja(), position));
                        startActivity(dodavanje);
                    }

                }
            });
            gridView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
                @Override
                public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                    int pozicijaDodavanja = gridView.getLastVisiblePosition(); //uzima poziciju posljednjeg elementa (onog za dodavanje kvizova)
                    if (position == pozicijaDodavanja) {
                        Intent dodavanje = new Intent(KvizoviAkt.this, DodajKvizAkt.class);
                        dodavanje.putExtra("data", new DataWrapper(kvizovi, kategorije, pitanja, -1));
                        startActivity(dodavanje);
                    } else {
                        Intent dodavanje = new Intent(KvizoviAkt.this, DodajKvizAkt.class);
                        dodavanje.putExtra("data", new DataWrapper(kvizovi, kategorije, kvizovi.get(position).getPitanja(), position));
                        startActivity(dodavanje);
                    }
                    return true;
                }
            });
            kvizAdapter.notifyDataSetChanged();

            //kraj
        }
        else {
            //normalni layout
            final Spinner spinnerKategorije = (Spinner) findViewById(R.id.spPostojeceKategorije);
            ArrayAdapter<Kategorija> dataAdapter = new ArrayAdapter<Kategorija>(this,
                    android.R.layout.simple_spinner_item, kategorije);
            dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinnerKategorije.setAdapter(dataAdapter);

            //samo kvizovi iz odabrane kategorije
            ArrayList<Kviz> odabrani = parsirajKvizove(JSONParsiranje);
            for (int i = 0; i < odabrani.size(); i++)
                if (!odabrani.get(i).getKategorija().getNaziv().equals(spinnerKategorije.getSelectedItem().toString()))
                   odabrani.remove(i);
                //kvizovi.clear();
               // kvizovi.addAll(odabrani);

            //  ArrayAdapter adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, k.getPitanja());
            final ListView mojaLista = (ListView) findViewById(R.id.lvKvizovi);

            final CustomAdapterKviz adapter = new CustomAdapterKviz(this, R.layout.lista, kopijaKvizovi);

            mojaLista.setAdapter(adapter);

            //dodjela pitanja u kviz
            //k.setPitanja(pitanja);


            mojaLista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapter, View view, int position, long arg) {
                    int pozicijaDodavanja = mojaLista.getLastVisiblePosition(); //uzima poziciju posljednjeg elementa (onog za dodavanje kvizova)
                    if (position == pozicijaDodavanja) { //ako klikne kratkim klikom na dodajKviz treba mu se i otvoriti DodajKvizAkt
                        Intent dodavanje = new Intent(KvizoviAkt.this, DodajKvizAkt.class);
                        dodavanje.putExtra("data", new DataWrapper(kvizovi, kategorije, pitanja, -1));
                        startActivity(dodavanje);
                    } else { //otvori IgrajKviz
                        Intent dodavanje = new Intent(KvizoviAkt.this, IgrajKvizAkt.class);
                        dodavanje.putExtra("data", new DataWrapper(kvizovi, kategorije, kvizovi.get(position).getPitanja(), position));
                        startActivity(dodavanje);
                    }

                }
            });
            mojaLista.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
                @Override
                public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                    int pozicijaDodavanja = mojaLista.getLastVisiblePosition(); //uzima poziciju posljednjeg elementa (onog za dodavanje kvizova)
                    if (position == pozicijaDodavanja) {
                        Intent dodavanje = new Intent(KvizoviAkt.this, DodajKvizAkt.class);
                        dodavanje.putExtra("data", new DataWrapper(kvizovi, kategorije, pitanja, -1));
                        startActivity(dodavanje);
                    } else {
                        Intent dodavanje = new Intent(KvizoviAkt.this, DodajKvizAkt.class);
                        dodavanje.putExtra("data", new DataWrapper(kvizovi, kategorije, kvizovi.get(position).getPitanja(), position));
                        startActivity(dodavanje);
                    }
                    return true;
                }
            });
            //filter po kategorijama
            spinnerKategorije.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> adapterac, View view, int position, long arg) {
                    //CustomAdapterPitanje adapter = new CustomAdapterPitanje(this, R.layout.lista, pitanja);
                    if (prviPutUcitan) prviPutUcitan = false;
                    if (!prviPutUcitan) {
                        int pozicijaDodavanja = spinnerKategorije.getLastVisiblePosition(); //uzima poziciju posljednjeg elementa (onog za dodavanje kvizova)
                        kopijaKvizovi.clear();
                        ;
                        for (int i = 0; i < kvizovi.size(); i++) {
                            if (kvizovi.get(i).getKategorija().getNaziv().equals(spinnerKategorije.getSelectedItem().toString()))
                                kopijaKvizovi.add(kvizovi.get(i));
                        }
                        boolean ima = false;
                        //brise i element za dodavanje pa treba pripaziti
                        for (int i = 0; i < kopijaKvizovi.size(); i++)
                            if (kopijaKvizovi.get(i).getNaziv().equals("Dodaj Kviz")) ima = true;
                        if (!ima)
                            kopijaKvizovi.add(new Kviz("Dodaj Kviz", android.R.drawable.ic_input_add));
                        adapter.notifyDataSetChanged();
                    }
                }

                @Override
                public void onNothingSelected(AdapterView<?> parentView) {
                    boolean ima = false;
                    for (int i = 0; i < kopijaKvizovi.size(); i++)
                        if (kopijaKvizovi.get(i).getNaziv().equals("Dodaj Kviz")) ima = true;
                    if (!ima)
                        kopijaKvizovi.add(new Kviz("Dodaj Kviz", R.drawable.ic_launcher_background));
                    adapter.notifyDataSetChanged();
                }
            });
        }
        new KreirajDokumentTask().execute("proba");
    }
    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

        Bundle bundle = new Bundle();
        bundle.putSerializable("Kviz", kvizovi);
        bundle.putSerializable("Kategorije", kategorije);
        bundle.putSerializable("Pitanja", pitanja);
        outState.putAll(bundle);
    }
    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        kvizovi=(ArrayList<Kviz>) savedInstanceState.getSerializable("Kviz");
        kategorije=(ArrayList<Kategorija>) savedInstanceState.getSerializable("Kategorije");
        pitanja=(ArrayList<Pitanje>) savedInstanceState.getSerializable("Pitanja");

    }
    @Override
    public void kreiranjeDetalja()
    {

    }
    @Override
    public void dajListu()
    {

    }
    @Override
    public void azuriranjeRangliste()
    {

    }

}
