package ba.unsa.etf.rma.aktivnosti;

public interface IDohvatiPitanjeDone {
    public void gotovo(String json);
}
