package ba.unsa.etf.rma.aktivnosti;

interface IDohvatiRanglisteDone {
    public void gotovoRangliste(String json);
}
