package ba.unsa.etf.rma.aktivnosti;

interface IDohvatiKategorijeDone {
    public void gotovoKat(String json);
}
