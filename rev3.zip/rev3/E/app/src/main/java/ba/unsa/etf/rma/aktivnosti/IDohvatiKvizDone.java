package ba.unsa.etf.rma.aktivnosti;

public interface IDohvatiKvizDone {
    public void gotovoKviz(String json);
}
