package ba.unsa.etf.rma.klase;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;

public class CustomAdapterPitanje extends ArrayAdapter<Pitanje> {

    private Context mContext;
    private int resources;
    private ArrayList<Pitanje> pitanja;

    public CustomAdapterPitanje(Context context, int res, ArrayList<Pitanje> pitanja) {
        super(context, res, pitanja);
        mContext = context;
        resources = res;
        this.pitanja = pitanja;

    }



    public View getView(int position, View convertView, ViewGroup parent) {

        LayoutInflater inflater = LayoutInflater.from(mContext);
        convertView = inflater.inflate(R.layout.lista, parent, false);
       // View view = inflater.inflate(R.layout.activity_main, null);

        ImageView imageView = (ImageView) convertView.findViewById(R.id.ikonaKviza);
        TextView textView = (TextView) convertView.findViewById(R.id.nazivTeksta);
        final Pitanje pitanjce = pitanja.get(position);
        textView.setText(pitanjce.getNaziv());
        //imageView.setImageDrawable(mContext.getResources().getDrawable(pitanjce.getSlikaPitanja()));
       /* row = inflater.inflate(R.layout.lista, parent, false);
        TextView title;
        ImageView i1 = (ImageView) row.findViewById(R.id.imgIcon);
        title = (TextView) row.findViewById(R.id.txtTitle);
        title.setText(imge.get(position));
        i1.setImageResource(imge[position]);
*/
        return convertView;
    }
}