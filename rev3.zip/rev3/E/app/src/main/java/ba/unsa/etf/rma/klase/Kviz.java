package ba.unsa.etf.rma.klase;

import java.io.Serializable;
import java.util.ArrayList;

import ba.unsa.etf.rma.R;

public class Kviz implements Serializable {
    private String naziv;
    private ArrayList<Pitanje> pitanja;
    private Kategorija kategorija;
    private static int brojac= 1;
    private String idUBazi="";

    public String getIdUBazi() {
        return idUBazi;
    }

    public void setIdUBazi(String idUBazi) {
        this.idUBazi = idUBazi;
    }

    public ArrayList<Pitanje> dajRandomPitanja()
    {
            java.util.Collections.shuffle(pitanja);
            return pitanja;
    }
    public boolean isPostavljenaSlika() {
        return postavljenaSlika;
    }

    public void setPostavljenaSlika(boolean postavljenaSlika) {
        this.postavljenaSlika = postavljenaSlika;
    }

    boolean postavljenaSlika=false;

    public Kviz(String naziv, int kviz) {
        this.naziv = naziv;
        this.slikaKviza=kviz;
        this.pitanja = new ArrayList<Pitanje>();
        this.kategorija = new Kategorija("Sve", kviz);
    }

    public Kviz(String naziv, ArrayList<Pitanje> pitanja, Kategorija kategorija, int slikaKviza) {
        this.naziv = naziv;
        this.pitanja = pitanja;
        this.kategorija = kategorija;
        this.slikaKviza = slikaKviza;
    }

    public int getSlikaKviza() {
        return slikaKviza;
    }

    public void setSlikaKviza(int slikaKviza) {
        this.slikaKviza = slikaKviza;
    }

    private int slikaKviza;

    public Kviz() {
        this.naziv= "Kviz"+ brojac;
        this.pitanja=new ArrayList<Pitanje>();
        this.slikaKviza=R.mipmap.ic_launcher;
        this.kategorija=new Kategorija("Sve", R.mipmap.ic_launcher);
        brojac++;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public ArrayList<Pitanje> getPitanja() {
        return pitanja;
    }

    public void setPitanja(ArrayList<Pitanje> pitanja) {
        this.pitanja = pitanja;
    }

    public Kategorija getKategorija() {
        return kategorija;
    }

    public void setKategorija(Kategorija kategorija) {
        this.kategorija = kategorija;
    }

    public void dodajPitanje(Pitanje p)
    {
        pitanja.add(p);
    }

    @Override
    public String toString() {
        return naziv;
    }
}
