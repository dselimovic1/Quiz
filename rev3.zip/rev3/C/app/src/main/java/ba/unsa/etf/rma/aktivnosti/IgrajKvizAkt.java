package ba.unsa.etf.rma.aktivnosti;

import android.app.FragmentManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.util.Pair;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.fragmenti.InformacijeFrag;
import ba.unsa.etf.rma.fragmenti.PitanjeFrag;
import ba.unsa.etf.rma.fragmenti.RanglistaFrag;
import ba.unsa.etf.rma.intentSevisi.intsDobaviUMogucaPitanjaIzBaze;
import ba.unsa.etf.rma.intentSevisi.intsDodajOstvareniRezultatURangListuIPrikaziJeZaTajKviz;
import ba.unsa.etf.rma.intentSevisi.resultReceiverZaSveIntentServise;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;

public class IgrajKvizAkt extends AppCompatActivity implements PitanjeFrag.KadKlikneNaOdgovor, resultReceiverZaSveIntentServise.Receiver
{
    private Kviz kvizKojiSeIgra;
    ArrayList<Pitanje> izmjesanaPitanja = new ArrayList<>();
    ArrayList<Pitanje> postavljenaPitanja = new ArrayList<>();
    private FrameLayout informacijePlace;
    private FrameLayout pitanjaPlace;

    private int brojTacnoOdogovrenih = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_igraj_kviz_akt);

        if(getIntent().getSerializableExtra("odabraniKvizZaIgrati") != null )
            kvizKojiSeIgra = (Kviz) getIntent().getSerializableExtra("odabraniKvizZaIgrati");

        FragmentManager fragmentManager = getFragmentManager();

        informacijePlace = (FrameLayout) findViewById(R.id.informacijePlace);
        pitanjaPlace = (FrameLayout) findViewById(R.id.pitanjaPlace);

        //POSTAVLJANJE PRVOG FRAGMENTA U FREJM
        InformacijeFrag informacijeFrag;
        informacijeFrag = (InformacijeFrag) fragmentManager.findFragmentById(R.id.informacijePlace);

        if(informacijeFrag == null)
        {
            informacijeFrag = new InformacijeFrag();

            Bundle bundle = new Bundle();
            bundle.putString("brojPostavljenjih", "0");
            bundle.putString("brojTacnoOdgovorenih", "0");
            bundle.putSerializable("odabraniKvizKojiSeIgra", kvizKojiSeIgra);
            informacijeFrag.setArguments(bundle);

            fragmentManager.beginTransaction().replace(R.id.informacijePlace, informacijeFrag).commit();
        }

        //POSTAVLJANJE DRUGOG FRAGMENTA U FREJM
        PitanjeFrag pitanjeFrag;
        pitanjeFrag = (PitanjeFrag) fragmentManager.findFragmentById(R.id.pitanjaPlace);

        if(pitanjeFrag == null)
        {
            pitanjeFrag = new PitanjeFrag();

            Bundle bundle = new Bundle();
            izmjesanaPitanja.clear();
            izmjesanaPitanja.addAll(kvizKojiSeIgra.dajRandomRedoslijedPitanja());

            if(izmjesanaPitanja.size() > 0)
            {
                bundle.putSerializable("pitanjeIzOdabranogKviza", izmjesanaPitanja.get(0));
                postavljenaPitanja.add(izmjesanaPitanja.get(0));
            }
            else
                bundle.putString("nemaOdgovora", "0");
            pitanjeFrag.setArguments(bundle);

            fragmentManager.beginTransaction().replace(R.id.pitanjaPlace, pitanjeFrag).commit();
        }

        fragmentManager.popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
    }


    @Override
    public void klikNaOdgovor(String tacan)
    {
        //AZURIRANJE PITANJE FRAGMENTA
        Bundle bundle2 = new Bundle();
        boolean azurirajZadnjiPut = false;

        if(izmjesanaPitanja.size() != postavljenaPitanja.size())
        {
            bundle2.putSerializable("pitanjeIzOdabranogKviza", izmjesanaPitanja.get(postavljenaPitanja.size()));
            postavljenaPitanja.add(izmjesanaPitanja.get(postavljenaPitanja.size()));
        }
        else
        {
            bundle2.putString("nemaOdgovora", "0");
            azurirajZadnjiPut = true;
        }

        PitanjeFrag pitanjeFrag = new PitanjeFrag();
        pitanjeFrag.setArguments(bundle2);

        getFragmentManager().beginTransaction().replace(R.id.pitanjaPlace, pitanjeFrag).commit();

        //AZURIRANJE INFORMACIJA FRAGMENTA
        if(tacan.equals(izmjesanaPitanja.get(postavljenaPitanja.size()-1).getTacan()))
            brojTacnoOdogovrenih++;

        Bundle bundle = new Bundle();

        // "-1", JER JE GORE IZNAD U ATRIBUT psotavljenaPitanja DODATO NOVO PITANJE KOJE NE TREBA DA SE RACUNA
        if(azurirajZadnjiPut == true)
        {
            bundle.putString("brojPostavljenjih", String.valueOf(postavljenaPitanja.size()));
            bundle.putInt("zadnjePitanje", 1);

            prikaziAlertDialogIDajRanglistu(brojTacnoOdogovrenih, postavljenaPitanja.size());
        }
        else
        bundle.putString("brojPostavljenjih", String.valueOf(postavljenaPitanja.size()-1));

        bundle.putString("brojTacnoOdgovorenih", String.valueOf(brojTacnoOdogovrenih));
        bundle.putSerializable("odabraniKvizKojiSeIgra", kvizKojiSeIgra);

        InformacijeFrag informacijeFrag = new InformacijeFrag();
        informacijeFrag.setArguments(bundle);

        getFragmentManager().beginTransaction().replace(R.id.informacijePlace, informacijeFrag).commit();
    }

    private void prikaziAlertDialogIDajRanglistu(int brojTacnoOdogovrenih, int brojPostavljenihPitanja)
    {
        double pomocniProcenat = 0;
        if(brojPostavljenihPitanja > 0)
            pomocniProcenat = Double.valueOf(brojTacnoOdogovrenih) / brojPostavljenihPitanja;

        final double procenat = pomocniProcenat;

        final AlertDialog alertDialog = new AlertDialog.Builder(this)
                .setTitle("UNESITE IME")
                .setMessage("Unesite ime kakao bi vas spasili u rang listu igara ovog kviza")
                .setPositiveButton(android.R.string.ok, null)
                .create();

        final EditText input = new EditText(this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT);
        input.setLayoutParams(lp);
        alertDialog.setView(input);

        alertDialog.setOnShowListener(new DialogInterface.OnShowListener() {

            @Override
            public void onShow(DialogInterface dialogInterface)
            {
                Button button = ((AlertDialog) alertDialog).getButton(AlertDialog.BUTTON_POSITIVE);

                button.setOnClickListener(new View.OnClickListener()
                {

                    @Override
                    public void onClick(View view)
                    {
                        if(input.getText().toString().trim().equals(""))
                        {
                            Log.w("NISI UPISAO IME", "Upisi ime, ne mozes ostaviti prazno!");
                        }
                        else
                        {
                            String unesenoImeZaRangListu = input.getText().toString();
                            dodajRezultatURangLitseIDajRangListuZaOvajKviz(kvizKojiSeIgra, procenat, unesenoImeZaRangListu);
                            alertDialog.dismiss();
                        }
                    }
                });
            }
        });
        alertDialog.show();
    }

    private void dodajRezultatURangLitseIDajRangListuZaOvajKviz(Kviz kvizKojiSeIgra, double procenat, String usernameZaRangListu)
    {
        Intent mojIntent = new Intent(Intent.ACTION_SYNC, null, this, intsDodajOstvareniRezultatURangListuIPrikaziJeZaTajKviz.class);
        resultReceiverZaSveIntentServise risiver = new resultReceiverZaSveIntentServise(new Handler());
        risiver.setReceiver(this);
        mojIntent.putExtra("risiver", risiver);
        mojIntent.putExtra("kviz koji se igra", kvizKojiSeIgra);
        mojIntent.putExtra("procenat tacno odgovorenih", procenat);
        mojIntent.putExtra("username za rang listu", usernameZaRangListu);
        startService(mojIntent);
    }

    @Override
    public void onReceiveResult(int resultCode, Bundle resultData)
    {
        switch (resultCode)
        {
            case intsDobaviUMogucaPitanjaIzBaze.STATUS_RUNNING:
                /* Ovdje ide kod koji obavještava korisnika da je poziv upućen */
                break;
            case intsDobaviUMogucaPitanjaIzBaze.STATUS_FINISHED:
                /* Dohvatanje rezultata i update UI */
                if(resultData.getSerializable("zadatak") != null &&
                        resultData.getSerializable("zadatak").equals("dobavljena rang lista za kviz"))
                {
                    ArrayList<Pair<String,Double>> ranglista = (ArrayList<Pair<String, Double>>) resultData.getSerializable("rezultat");

                    FragmentManager fragmentManager = getFragmentManager();

                    RanglistaFrag ranglistaFrag =  new RanglistaFrag();

                    Bundle bundle = new Bundle();
                    bundle.putSerializable("ranglista", ranglista);
                    ranglistaFrag.setArguments(bundle);
                    fragmentManager.beginTransaction().replace(R.id.pitanjaPlace, ranglistaFrag).commit();
                    fragmentManager.popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
                }

                break;
            case intsDobaviUMogucaPitanjaIzBaze.STATUS_ERROR:
                /* Slučaj kada je došlo do greške */
                android.support.v7.app.AlertDialog alertDialog = new android.support.v7.app.AlertDialog.Builder(this).create();
                alertDialog.setTitle("PROBLEM PRI UNOSENJU U RANG LISTU");
                alertDialog.setMessage("nije se rezultat ispravno unio u rang listu!");
                alertDialog.setButton(android.app.AlertDialog.BUTTON_NEUTRAL, "OK",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });
                alertDialog.show();
                break;
        }
    }
}
