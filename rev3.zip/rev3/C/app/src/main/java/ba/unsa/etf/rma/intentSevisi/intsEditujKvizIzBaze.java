package ba.unsa.etf.rma.intentSevisi;

import android.app.IntentService;
import android.content.Intent;
import android.os.Bundle;
import android.os.ResultReceiver;
import android.util.Log;
import android.util.Pair;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;

public class intsEditujKvizIzBaze extends IntentService
{
    public static final int STATUS_RUNNING = 0;
    public static final int STATUS_FINISHED = 1;
    public static final int STATUS_ERROR = 2;

    public intsEditujKvizIzBaze()
    {
        super(null);
    }

    public intsEditujKvizIzBaze(String name)
    {
        super(name);
        // Sav posao koji treba da obavi konstruktor treba da se
        // nalazi ovdje
    }

    @Override
    public void onCreate()
    {
        super.onCreate();
        // Akcije koje se trebaju obaviti pri kreiranju servisa
    }

    @Override
    protected void onHandleIntent(Intent intent)
    {
        // Kod koji se nalazi ovdje će se izvršavati u posebnoj niti
        // Ovdje treba da se nalazi funkcionalnost servisa koja je
        // vremenski zahtjevna

        final ResultReceiver resultReceiver = intent.getParcelableExtra("risiver");
        //U TRENUTKU KADA JE POZVAN OVAJ INTENT SERVIS, VEC SE ZNA DA SU DVA PROSLJEDJENA KVIA RAZLICITA BAR PO NECEMU
        Kviz orginalniKvizKojiSeMijenja = (Kviz) intent.getSerializableExtra("orginalniKvizKojiSeMijenja");
        Kviz uOvajKvizSeMijenja = (Kviz) intent.getSerializableExtra("uOvajKvizSeMijenja");
        boolean promijenjenoImeKviza = intent.getExtras().getBoolean("promijenjenoImeKviza");

        String token = null;
        token = dajToken();

        boolean vratiGresku = false;
        if(promijenjenoImeKviza == true && daLiVecPostojiKviz(uOvajKvizSeMijenja, token) == true)
        vratiGresku = true;
        else if (promijenjenoImeKviza == false)
        {
            try
            {
                String spojenoIme = URLEncoder.encode(orginalniKvizKojiSeMijenja.getNaziv(), "utf-8");

                String url = "https://firestore.googleapis.com/v1/projects/spirala2019nedzad/databases/(default)/documents/Kvizovi/KVIZ"+spojenoIme+"?currentDocument.exists=true";

                URL urlObjekat = new URL(url);

                HttpURLConnection konekcija = (HttpURLConnection) urlObjekat.openConnection();

                konekcija.setRequestProperty("Authorization", "Bearer "+token);

                //govori koju akciju vrsimo
                konekcija.setRequestMethod("PATCH");
                //govori u kojem formatu upisujemo u bazu
                konekcija.setRequestProperty("Content-Type", "appliction/json");
                //namjesta da se: prihvati response i format u kojem se prihvata
                konekcija.setRequestProperty("Accept", "appliation/json");

                StringBuilder dokuemntBilder = new StringBuilder("{ \"fields\": " +
                        "{ \"naziv\": { \"stringValue\": \""+uOvajKvizSeMijenja.getNaziv()+"\"}, " +
                        "  \"idKategorije\": { \"stringValue\":\""+"KATEGORIJA"+uOvajKvizSeMijenja.getKategorija().getNaziv()+"\"}, " +
                        " \"pitanja\" : { \"arrayValue\" : { \"values\" : [");
                for(int i=0; i<uOvajKvizSeMijenja.getPitanja().size(); i++)
                {
                    String IDubacenogPitanja = "PITANJE"+uOvajKvizSeMijenja.getPitanja().get(i).getNaziv();
                    String jednoPitanje = " { \"stringValue\": \""+IDubacenogPitanja+"\"}";

                    dokuemntBilder.append(jednoPitanje);
                    if(i+1 != uOvajKvizSeMijenja.getPitanja().size())
                        dokuemntBilder.append(", ");
                }
                dokuemntBilder.append("]}} }}");

                String dokument = dokuemntBilder.toString();

                OutputStream outputStream = konekcija.getOutputStream();
                byte[] unos = dokument.getBytes();
                outputStream.write(unos, 0, unos.length);

                InputStream odgovor = konekcija.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(odgovor, "utf-8"));
                StringBuilder response = new StringBuilder();
                String responseLine = null;
                while((responseLine = bufferedReader.readLine()) != null)
                    response.append(responseLine.trim());

                Log.d("ODGOVOR", response.toString());
                vratiGresku = false;
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }

        }
        else if(promijenjenoImeKviza == true)
        {
            //AKO JE PROMJENJEO IME KVIZA, A KVIZ SA TAKVIM IMENOM NE POSTOJI U BAZI BRISE SE STARI, A DODJE NOVI
            // ZBOG NJEGOVOG ID-a

            // I- dodas kviz sa izmjenjenim nazivom
            try
            {
                String spojenoIme = URLEncoder.encode(uOvajKvizSeMijenja.getNaziv(), "utf-8");

                String url = "https://firestore.googleapis.com/v1/projects/spirala2019nedzad/databases/(default)/documents/Kvizovi?documentId=KVIZ"+spojenoIme;

                URL urlObjekat = new URL(url);

                HttpURLConnection konekcija = (HttpURLConnection) urlObjekat.openConnection();

                konekcija.setRequestProperty("Authorization", "Bearer "+token);

                //govori koju akciju vrsimo
                konekcija.setRequestMethod("POST");
                //govori u kojem formatu upisujemo u bazu
                konekcija.setRequestProperty("Content-Type", "appliction/json");
                //namjesta da se: prihvati response i format u kojem se prihvata
                konekcija.setRequestProperty("Accept", "appliation/json");

                StringBuilder dokuemntBilder = new StringBuilder("{ \"fields\": " +
                        "{ \"naziv\": { \"stringValue\": \""+uOvajKvizSeMijenja.getNaziv()+"\"}, " +
                        "  \"idKategorije\": { \"stringValue\":\"KATEGORIJA"+uOvajKvizSeMijenja.getKategorija().getNaziv()+"\"}, " +
                        " \"pitanja\" : { \"arrayValue\" : { \"values\" : [");
                for(int i=0; i<uOvajKvizSeMijenja.getPitanja().size(); i++)
                {
                    String IDubacenogPitanja = "PITANJE"+uOvajKvizSeMijenja.getPitanja().get(i).getNaziv();
                    String jednoPitanje = " { \"stringValue\": \""+IDubacenogPitanja+"\"}";

                    dokuemntBilder.append(jednoPitanje);
                    if(i+1 != uOvajKvizSeMijenja.getPitanja().size())
                        dokuemntBilder.append(", ");
                }
                dokuemntBilder.append("]}} }}");

                String dokument = dokuemntBilder.toString();

                OutputStream outputStream = konekcija.getOutputStream();
                byte[] unos = dokument.getBytes();
                outputStream.write(unos, 0, unos.length);

                InputStream odgovor = konekcija.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(odgovor, "utf-8"));
                StringBuilder response = new StringBuilder();
                String responseLine = null;
                while((responseLine = bufferedReader.readLine()) != null)
                    response.append(responseLine.trim());

                Log.d("ODGOVOR", response.toString());
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }

            //II-izbrises stari kviz (zato jer mu drugacije ne znas promijenit id dokumenta)
            try
            {
                String spojenoIme = URLEncoder.encode(orginalniKvizKojiSeMijenja.getNaziv(), "utf-8");

                String url = "https://firestore.googleapis.com/v1/projects/spirala2019nedzad/databases/(default)/documents/Kvizovi/KVIZ"+spojenoIme;

                URL urlObjekat = new URL(url);

                HttpURLConnection konekcija = (HttpURLConnection) urlObjekat.openConnection();

                konekcija.setRequestProperty("Authorization", "Bearer "+token);

                //govori koju akciju vrsimo
                konekcija.setRequestMethod("DELETE");
                //govori u kojem formatu upisujemo u bazu
                konekcija.setRequestProperty("Content-Type", "appliction/json");
                //namjesta da se: prihvati response i format u kojem se prihvata
                konekcija.setRequestProperty("Accept", "appliation/json");

                int responseCode = konekcija.getResponseCode();

                vratiGresku = false;
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }

            //AKO SE APDEJTUJE IME KVIZA; ONDA SE MORA ISPISTATI DA LI POSTOJI RANGLISTA ZA TAJ KVIZ I APDEJTOVATI NJU ONDA
            if(daLiPostojiRanglistaZaKviz(orginalniKvizKojiSeMijenja.getNaziv(), token) == true)
            {
                poromijeniPoljeRanglisteINjenId(orginalniKvizKojiSeMijenja, uOvajKvizSeMijenja, token);
            }
        }

        if(vratiGresku == true)
        {
            resultReceiver.send(STATUS_ERROR, new Bundle());
        }
        else
        {
            Bundle bundle = new Bundle();
            bundle.putString("zadatak", "editovan kviz");
            resultReceiver.send(STATUS_FINISHED, bundle);
        }
    }

    private boolean daLiPostojiRanglistaZaKviz(String nazivKvizaZaKojiJeVezanaRanglista, String token)
    {
        try
        {
            String spojenoIme = URLEncoder.encode(nazivKvizaZaKojiJeVezanaRanglista, "utf-8");
            String url = "https://firestore.googleapis.com/v1/projects/spirala2019nedzad/databases/(default)/documents/Rangliste/RANGLISTA"+spojenoIme;
            URL urlObjekat = null;

            urlObjekat = new URL(url);
            HttpURLConnection konekcija = (HttpURLConnection) urlObjekat.openConnection();

            //govori koju akciju vrsimo
            konekcija.setRequestMethod("GET");
            //ovaj property mora biti podesen da bi mogao koristiti JSON format za slatnje zahtjeva
            konekcija.setRequestProperty("Content-Type", "appliction/json");
            //namjesta da se: prihvati response i format u kojem se prihvata
            konekcija.setRequestProperty("Accept", "appliation/json");
            konekcija.setRequestProperty("Authorization", "Bearer "+token);

            InputStream odgovor = konekcija.getInputStream();
            String rezultat = convertStreamToString(odgovor);

        }
        catch (Exception e)
        {
            Log.d("NE POSTOJI RANGLISTA", "ne postoji ranglista za kviz: \""+nazivKvizaZaKojiJeVezanaRanglista+"\" u bazi");
            return false;
        }

        return  true;
    }

    public boolean daLiVecPostojiKviz(Kviz kvizKojiSeDodajeUBazu, String token)
    {
        try
        {
            String spojenoIme = URLEncoder.encode(kvizKojiSeDodajeUBazu.getNaziv(), "utf-8");
            String url = "https://firestore.googleapis.com/v1/projects/spirala2019nedzad/databases/(default)/documents/Kvizovi/KVIZ"+spojenoIme;
            URL urlObjekat = null;

            urlObjekat = new URL(url);
            HttpURLConnection konekcija = (HttpURLConnection) urlObjekat.openConnection();

            //govori koju akciju vrsimo
            konekcija.setRequestMethod("GET");
            //ovaj property mora biti podesen da bi mogao koristiti JSON format za slatnje zahtjeva
            konekcija.setRequestProperty("Content-Type", "appliction/json");
            //namjesta da se: prihvati response i format u kojem se prihvata
            konekcija.setRequestProperty("Accept", "appliation/json");
            konekcija.setRequestProperty("Authorization", "Bearer "+token);

            InputStream odgovor = konekcija.getInputStream();
            String rezultat = convertStreamToString(odgovor);

        }
        catch (Exception e)
        {
            Log.d("NE POSTOJI KVIZ", "ne postoji kviz sa imenom: \""+ kvizKojiSeDodajeUBazu.getNaziv()+"\" u bazi");
            return false;
        }

        return  true;
    }

    private boolean poromijeniPoljeRanglisteINjenId(Kviz kvizKojiSeMijenja, Kviz uOvajKvizSeMijenja, String token)
    {
        ArrayList<Pair<String, Double>> alRanglista = new ArrayList<>();
        boolean uspjesnoUcitanaRangLista = false;
        // I- ucitas ranglistu sa imenom koje je bilo prije edita
        try
        {
            String query = "{\n" +
                    "\"structuredQuery\": {\n" +
                    "\"where\": {\n" +
                    "\"fieldFilter\": {\n" +
                    "\"field\": {\"fieldPath\": \"nazivKviza\"}, \n" +
                    "\"op\": \"EQUAL\",\n" +
                    "\"value\": {\"stringValue\": \"" + kvizKojiSeMijenja.getNaziv() + "\"}\n" +
                    "}\n" +
                    "},\n" +
                    "\"select\": {\"fields\": [ {\"fieldPath\": \"nazivKviza\"}, {\"fieldPath\": \"lista\"} ] }, \n" +
                    "\"from\": [{\"collectionId\" : \"Rangliste\"}], \n" +
                    "\"limit\" : 1000\n" +
                    "}\n" +
                    "}";

            String url = "https://firestore.googleapis.com/v1/projects/spirala2019nedzad/databases/(default)/documents:runQuery";

            URL urlObjekat = new URL(url);

            HttpURLConnection konekcija = (HttpURLConnection) urlObjekat.openConnection();

            konekcija.setRequestProperty("Authorization", "Bearer " + token);

            //govori koju akciju vrsimo
            konekcija.setRequestMethod("POST");
            //ovaj property mora biti podesen da bi mogao koristiti JSON format za slatnje zahtjeva
            konekcija.setRequestProperty("Content-Type", "appliction/json");
            //namjesta da se: prihvati response i format u kojem se prihvata
            konekcija.setRequestProperty("Accept", "appliation/json");
            konekcija.setRequestProperty("Authorization", "Bearer " + token);

            OutputStream outputStream = konekcija.getOutputStream();
            byte[] unos = query.getBytes();
            outputStream.write(unos, 0, unos.length);

            InputStream odgovor = konekcija.getInputStream();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(odgovor, "utf-8"));
            StringBuilder response = new StringBuilder();
            String responseLine = null;
            while ((responseLine = bufferedReader.readLine()) != null)
                response.append(responseLine.trim());

            //------------------------
            JSONArray rezultatiKverija = new JSONArray(response.toString());
            try
            {
                //ovdje ce vec baciti izuzetak ako kveri nije dao rezultate
                JSONObject jedanRezultatKverijaIzuzetak = rezultatiKverija.getJSONObject(0);
                JSONObject documentsIzuzetak = jedanRezultatKverijaIzuzetak.getJSONObject("document");
                //----

                for (int i = 0; i < rezultatiKverija.length(); i++)
                {
                    JSONObject jedanRezultatKverija = rezultatiKverija.getJSONObject(i);
                    JSONObject document = jedanRezultatKverija.getJSONObject("document");

                    JSONObject jsonFields = document.getJSONObject("fields");

                    JSONObject jsonNaziv = jsonFields.getJSONObject("nazivKviza");
                    String nazivKviza = jsonNaziv.getString("stringValue");

                    JSONObject jsonLista = jsonFields.getJSONObject("lista");
                    JSONObject jsonMapValue1 = jsonLista.getJSONObject("mapValue");
                    JSONObject jsonFields2 = jsonMapValue1.getJSONObject("fields");

                    boolean ponavljajUcitavanje = true;
                    int brojac = 1;

                    while(ponavljajUcitavanje)
                    {
                        //"username", "ostavreniRezultat" su kljuc i vrijednost
                        Pair<String, Double> pairJedanRezultatigre;

                        try
                        {
                            JSONObject jsonRedniBrojKviza = jsonFields2.getJSONObject(String.valueOf(brojac));
                            JSONObject jsonMapValue2 = jsonRedniBrojKviza.getJSONObject("mapValue");
                            JSONObject jsonFields3 = jsonMapValue2.getJSONObject("fields");

                            String stringFields3 = jsonFields3.toString();
                            String[] uzmiIme = stringFields3.split("\"");
                            String username = uzmiIme[1];

                            JSONObject jsonUsername = jsonFields3.getJSONObject(username);
                            double ostverniRezultat = jsonUsername.getDouble("doubleValue");

                            pairJedanRezultatigre = new Pair<>(username, ostverniRezultat);
                            alRanglista.add(pairJedanRezultatigre);

                            brojac++;
                        }
                        catch(JSONException e)
                        {
                            ponavljajUcitavanje = false;
                        }
                    }
                }
            }
            catch (JSONException e)
            {
                //KVERI NIJE VRATI REZULTATE
            }

            uspjesnoUcitanaRangLista = true;

        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (ProtocolException e) {
            e.printStackTrace();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }

        // II- DODAVANJE RANGLISTE SA PROMJENJENIM IMENOM
        boolean uspjesnoUpisanaRanlistaSaNovimImenom = false;
        try
        {
            String spojenoIme = URLEncoder.encode(uOvajKvizSeMijenja.getNaziv(), "utf-8");

            String url = "https://firestore.googleapis.com/v1/projects/spirala2019nedzad/databases/(default)/documents/Rangliste?documentId=RANGLISTA"+spojenoIme;

            URL urlObjekat = new URL(url);

            HttpURLConnection konekcija = (HttpURLConnection) urlObjekat.openConnection();

            konekcija.setRequestProperty("Authorization", "Bearer "+token);

            //govori koju akciju vrsimo
            konekcija.setRequestMethod("POST");
            //govori u kojem formatu upisujemo u bazu
            konekcija.setRequestProperty("Content-Type", "appliction/json");
            //namjesta da se: prihvati response i format u kojem se prihvata
            konekcija.setRequestProperty("Accept", "appliation/json");


            StringBuilder dokuemntBilder = new StringBuilder("{ \"fields\": " +
                    "{ \"nazivKviza\": { \"stringValue\": \"" + uOvajKvizSeMijenja.getNaziv() + "\"}, " +
                    " \"lista\" : { \"mapValue\" : { \"fields\" : { ");
            int pozicija = 1;
            for(int i=0; i<alRanglista.size(); i++)
            {
                dokuemntBilder.append(" \""+pozicija+"\" : { \"mapValue\" : { \"fields\" : { " +
                        " \"" + alRanglista.get(i).first + "\" : { \"doubleValue\" : \"" + alRanglista.get(i).second + "\"}}}}");

                if(i != (alRanglista.size()-1))
                    dokuemntBilder.append(", ");

                pozicija++;
            }
            dokuemntBilder.append(" }}}}}");

            String dokument = dokuemntBilder.toString();

            OutputStream outputStream = konekcija.getOutputStream();
            byte[] unos = dokument.getBytes();
            outputStream.write(unos, 0, unos.length);

            InputStream odgovor = konekcija.getInputStream();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(odgovor, "utf-8"));
            StringBuilder response = new StringBuilder();
            String responseLine = null;
            while((responseLine = bufferedReader.readLine()) != null)
                response.append(responseLine.trim());

            Log.d("ODGOVOR", response.toString());
            uspjesnoUpisanaRanlistaSaNovimImenom = true;
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }

        // III- brisanje rangliste sa prijasnjim nazivom
        boolean uspjesnoIzbrisanaRanglistaSaProslimImenom = false;
        if(uspjesnoUpisanaRanlistaSaNovimImenom == true)
        {
            try
            {
                String spojenoIme = URLEncoder.encode(kvizKojiSeMijenja.getNaziv(), "utf-8");

                String url = "https://firestore.googleapis.com/v1/projects/spirala2019nedzad/databases/(default)/documents/Rangliste/RANGLISTA"+spojenoIme;

                URL urlObjekat = new URL(url);

                HttpURLConnection konekcija = (HttpURLConnection) urlObjekat.openConnection();

                konekcija.setRequestProperty("Authorization", "Bearer "+token);

                //govori koju akciju vrsimo
                konekcija.setRequestMethod("DELETE");
                //govori u kojem formatu upisujemo u bazu
                konekcija.setRequestProperty("Content-Type", "appliction/json");
                //namjesta da se: prihvati response i format u kojem se prihvata
                konekcija.setRequestProperty("Accept", "appliation/json");

                int responseCode = konekcija.getResponseCode();

                uspjesnoIzbrisanaRanglistaSaProslimImenom = true;
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }
        }

        if(uspjesnoUcitanaRangLista == true && uspjesnoUpisanaRanlistaSaNovimImenom == true
                && uspjesnoIzbrisanaRanglistaSaProslimImenom == true)
            return true;

        return false;
    }

    public String dajToken()
    {
        String token = null;

        try
        {
            InputStream is = getBaseContext().getResources().openRawResource(R.raw.secret);
            GoogleCredential credentials = null;
            credentials = GoogleCredential.fromStream(is).
                    createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();

            token = credentials.getAccessToken();

            is.close();
            //Log.d("TOKEN", token);
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }

        return token;
    }

    public String convertStreamToString(InputStream is)
    {
        //BufferedReader je klasa wrapper za oboje "InputStreamReader/FileReader". Koristeci bufffer(spremink), efikasnije odradjuje citanje bajta(tj. charova, jer je jedan char jena bajt)
        BufferedReader reader = new BufferedReader(new InputStreamReader(is));

        //String is immutable, if you try to alter their values, another object gets created, whereas StringBuffer and StringBuilder are mutable so they can change their values.
        // Thread-Safety Difference: The difference between StringBuffer and StringBuilder is that StringBuffer is thread-safe.
        StringBuilder sb = new StringBuilder();
        String line = null;
        try
        {
            while ((line = reader.readLine()) != null)
                sb.append(line + "\n");
        }
        catch (IOException e)
        {
            e.getStackTrace();
        }
        finally
        {
            try
            {
                is.close();
            }
            catch (IOException e)
            {
                e.getStackTrace();
            }
        }

        return sb.toString();
    }
}

