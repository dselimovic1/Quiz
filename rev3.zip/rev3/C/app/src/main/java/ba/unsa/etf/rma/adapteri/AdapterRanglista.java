package ba.unsa.etf.rma.adapteri;

import android.content.Context;
import android.util.Pair;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.maltaisn.icondialog.IconHelper;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kviz;

public class AdapterRanglista extends ArrayAdapter<Pair<String, Double>>
{
    private Context context;
    private ArrayList<Pair<String, Double>> ranglista;

    public AdapterRanglista(Context context, int textViewResourceId, ArrayList<Pair<String, Double>> values)
    {
        super(context, textViewResourceId, values);

        this.context = context;
        this.ranglista = values;
    }

    public int getCount()
    {
        return ranglista.size();
    }

    public Pair<String, Double> getItem(int position){
        return ranglista.get(position);
    }

    public long getItemId(int position){
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent)
    {
        final Pair<String, Double> jedanRed = getItem(position);

        if(convertView == null)
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.adapter_ranglista, parent, false);

        TextView redniBroj = (TextView) convertView.findViewById(R.id.tvRedniBroj);
        TextView username = (TextView) convertView.findViewById(R.id.tvUsername);
        TextView ostvareniUcinak = (TextView) convertView.findViewById(R.id.tvProcenatTacnoOdogovrenih);

        String redniBrojReda = String.valueOf(position+1);
        redniBroj.setText(redniBrojReda);
        username.setText(jedanRed.first);
        ostvareniUcinak.setText(String.valueOf(jedanRed.second));

        return convertView;
    }

}
