package ba.unsa.etf.rma.aktivnosti;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Handler;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.intentSevisi.intsDajSveKategorijeSveKvizoveSvaPitanja;
import ba.unsa.etf.rma.intentSevisi.intsDobaviUMogucaPitanjaIzBaze;
import ba.unsa.etf.rma.intentSevisi.intsDodajPitanjeUBazu;
import ba.unsa.etf.rma.intentSevisi.intsEditujKvizIzBaze;
import ba.unsa.etf.rma.intentSevisi.resultReceiverZaSveIntentServise;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;

public class DodajPitanjeAkt extends AppCompatActivity implements resultReceiverZaSveIntentServise.Receiver
{
    //ATRIBUTI
    private ListView lvOdgovori;
    private EditText etNaziv;
    private EditText etOdgovor;
    private Button btnDodajOdgovor;
    private Button btnDodajTacan;
    private Button btnDodajPitanje;

    private Pitanje novoPitanje = new Pitanje();
    private ArrayList<Pitanje> alPitanjaUKvizu;

    private ArrayList<Pitanje> alSvaPitanja = new ArrayList<>();
    private ArrayList<Kategorija> alSveKategorije = new ArrayList<>();
    private ArrayList<Kviz> alSviKvizovi = new ArrayList<>();

    private ArrayAdapter<String> adapterOdgovora;
    private int pozicijaTacnog = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dodaj_pitanje_akt);

        postaviAtribute();

        lvOdgovori = (ListView) findViewById(R.id.lvOdgovori);
        etNaziv = (EditText) findViewById(R.id.etNaziv);
        etOdgovor = (EditText) findViewById(R.id.etOdgovor);
        btnDodajOdgovor = (Button) findViewById(R.id.btnDodajOdgovor);
        btnDodajPitanje = (Button) findViewById(R.id.btnDodajPitanje);
        btnDodajTacan = (Button) findViewById(R.id.btnDodajTacan);

        alSveKategorije = (ArrayList<Kategorija>) getIntent().getSerializableExtra("sveKategorije");
        alSviKvizovi = (ArrayList<Kviz>) getIntent().getSerializableExtra("sviKvizovi");
        alSvaPitanja = (ArrayList<Pitanje>) getIntent().getSerializableExtra("svaPitanja");

        //https://stackoverflow.com/questions/41594562/change-color-of-one-line-of-a-listview?fbclid=IwAR03bIJ6UF4nrh9KjiOI_oCEVD2wMdv85bIlKRgFMc03TYTNmrfCQArnRJ4
        adapterOdgovora = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, novoPitanje.getOdgovori())
        {
          @Override
          public View getView(int position, View convertView, ViewGroup parent)
          {
              View view = super.getView(position, convertView, parent);

              if(getPozicijaTacnog() != -1 && position == getPozicijaTacnog())
                  view.setBackgroundColor(Color.parseColor("#8BC34A"));
              else
                  view.setBackgroundColor(Color.parseColor("#FFFFFF"));

              return view;
          }
        };
        lvOdgovori.setAdapter(adapterOdgovora);

        lvOdgovori.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                if(novoPitanje.getTacan() != null && novoPitanje.getTacan().equals(novoPitanje.getOdgovori().get(position)))
                {
                    novoPitanje.setTacan(null);
                    btnDodajTacan.setEnabled(true);
                }
                novoPitanje.getOdgovori().remove(position);

                //adapterListaOdgovra.notifyDataSetChanged();
                adapterOdgovora.notifyDataSetChanged();
            }
        });

        btnDodajOdgovor.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v)
            {
                if(etOdgovor.getText().toString().trim().equals(""))
                {
                    Toast.makeText(DodajPitanjeAkt.this, "niste unijeli odgovor", Toast.LENGTH_LONG).show();
                    return;
                }

                if(imaLiIstogOdgovora()==true)
                    return;

                novoPitanje.getOdgovori().add(etOdgovor.getText().toString().trim());
                //adapterListaOdgovra.notifyDataSetChanged();
                adapterOdgovora.notifyDataSetChanged();
            }
        });

        btnDodajTacan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                if(etOdgovor.getText().toString().trim().equals(""))
                {
                    Toast.makeText(DodajPitanjeAkt.this, "niste unijeli odgovor", Toast.LENGTH_LONG).show();
                    return;
                }

                if(novoPitanje.getTacan() != null)
                    return;

                if(imaLiIstogOdgovora()==true)
                    return;

                novoPitanje.getOdgovori().add(etOdgovor.getText().toString().trim());
                novoPitanje.setTacan(etOdgovor.getText().toString().trim());

                btnDodajTacan.setEnabled(false);

                //adapterListaOdgovra.notifyDataSetChanged();
                adapterOdgovora.notifyDataSetChanged();
            }
        });

        btnDodajPitanje.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v)
            {
                boolean ispravniUnosi= true;

                if( imaLiPitanjeUIstomKvizuSIstimImenom()==true )
                {
                    ispravniUnosi = false;
                    Toast.makeText(DodajPitanjeAkt.this, "vec postoji pitanje u kvizu s tim imenom",Toast.LENGTH_LONG).show();
                    etNaziv.setBackgroundColor(Color.parseColor("#F44336"));
                }
                else
                    etNaziv.setBackgroundColor(Color.parseColor("#FFFFFF"));


                if(etNaziv.getText().toString().equals(""))
                {
                    ispravniUnosi = false;
                    Toast.makeText(DodajPitanjeAkt.this, "unesite ime pitanja",Toast.LENGTH_LONG).show();
                    etNaziv.setBackgroundColor(Color.parseColor("#F44336"));
                }
                else if(ispravniUnosi)
                    etNaziv.setBackgroundColor(Color.parseColor("#FFFFFF"));

                if(novoPitanje.getTacan() == null)
                {
                    ispravniUnosi = false;
                    Toast.makeText(DodajPitanjeAkt.this, "pitanje mora imati tacan odgovor",Toast.LENGTH_LONG).show();
                }

                /*if(novoPitanje.getOdgovori().size() == 1)
                {
                    ispravniUnosi = false;
                    Toast.makeText(DodajPitanjeAkt.this, "pitanje mora imati barem jedan netacan i tacan odgovor",Toast.LENGTH_LONG).show();
                }*/

                if(ispravniUnosi)
                {
                    novoPitanje.setNaziv(etNaziv.getText().toString().trim());
                    dodajPitanjeUBazu(novoPitanje);

                    /*//SVE OVO SE PREBACUJE ON REVIEVE RESULT
                    Intent mojIntent = new Intent(DodajPitanjeAkt.this, DodajKvizAkt.class);

                    alSvaPitanja.add(novoPitanje);

                    ArrayList<Pitanje> alMogucaPitanja = (ArrayList<Pitanje>)getIntent().getSerializableExtra("trenutnoStanjeAlMogucaPitanja");
                    String etNaziv =(String) getIntent().getStringExtra("trenutnoStanjeEtNaziv");
                    String spKategorije = (String) getIntent().getStringExtra("trenutnoStanjeSpKategorije");
                    ArrayList<Kategorija> alSveKategorije = (ArrayList<Kategorija>) getIntent().getSerializableExtra("kategorijaSve");
                    ArrayList<Kviz> alSviKvizovi = (ArrayList<Kviz>) getIntent().getSerializableExtra("sviKvizovi");



                    alPitanjaUKvizu.add(novoPitanje);
                    mojIntent.putExtra("alDodanaPitanjaVrati", alPitanjaUKvizu);
                    mojIntent.putExtra("alMogucaPitanjaVrati", alMogucaPitanja);
                    mojIntent.putExtra("etNazivVrati", etNaziv);
                    mojIntent.putExtra("spKategorijeVrati", spKategorije);

                    mojIntent.putExtra("kljucSvaPitanja", alSvaPitanja);
                    mojIntent.putExtra("kljucArraySveKategorije", alSveKategorije);
                    mojIntent.putExtra("kljucArraySviKvizovi", alSviKvizovi);

                    mojIntent.putExtra("dodavanjePitanja", "dodavanjePitanja");

                    mojIntent.putExtra("nacinRada", getIntent().getStringExtra("nacinRada"));

                    if(getIntent().getStringExtra("nacinRada").equals("editovanjeKviza"))
                    {
                        mojIntent.putExtra("odabraniKviz", getIntent().getSerializableExtra("odabraniKviz"));
                        mojIntent.putExtra("pozicijaKvizaKojiSeMijenja", getIntent().getIntExtra("pozicijaKvizaKojiSeMijenja", 0));
                    }

                    DodajPitanjeAkt.this.startActivity(mojIntent);*/
                }
            }
        });
    }

    private void dodajPitanjeUBazu(Pitanje novododanoPitanje)
    {
        Intent mojIntent = new Intent(Intent.ACTION_SYNC, null, this, intsDodajPitanjeUBazu.class);
        resultReceiverZaSveIntentServise risiver = new resultReceiverZaSveIntentServise(new Handler());
        risiver.setReceiver(this);
        mojIntent.putExtra("risiver", risiver);
        mojIntent.putExtra("pitanjeKojeSeDodajeUBazu", novododanoPitanje);
        startService(mojIntent);
    }

    @Override
    public void onResume()
    {
        super.onResume();

        for(int i=0; i<novoPitanje.getOdgovori().size(); i++)
        {
            if(lvOdgovori.getChildAt(i).toString().equals(novoPitanje.getTacan()))
            {
                lvOdgovori.getChildAt(i).setBackgroundColor(Color.parseColor("##8BC34A"));
                btnDodajTacan.setEnabled(false);
                break;
            }
        }
    }

    private boolean imaLiPitanjeUIstomKvizuSIstimImenom()
    {
        for(int i = 0; i< alPitanjaUKvizu.size(); i++)
        {
            if(alPitanjaUKvizu.get(i).getNaziv().equals(etNaziv.getText().toString()))
                return true;

        }
        return false;
    }

    private void postaviAtribute()
    {
        //UVIJEK ISPUNJEN UVJET, ALI ZA SVAKI SLUCAJ
        if(getIntent().getSerializableExtra("dodanaPitanja") != null)
        {
            alSvaPitanja = (ArrayList<Pitanje>) getIntent().getSerializableExtra("svaPitanja");
            alPitanjaUKvizu = (ArrayList<Pitanje>) getIntent().getSerializableExtra("dodanaPitanja");
        }
    }

    private boolean imaLiIstogOdgovora()
    {
        for(int i=0; i<novoPitanje.getOdgovori().size(); i++)
        {
            if(etOdgovor.getText().toString().equals(novoPitanje.getOdgovori().get(i)))
            {
                Toast.makeText(DodajPitanjeAkt.this, "taj odgovor vec postoji", Toast.LENGTH_LONG).show();
                return true;
            }
        }
        return false;
    }

    private int getPozicijaTacnog()
    {
        if(novoPitanje.getTacan()== null)
            return -1;

        for(int i=0; i<novoPitanje.getOdgovori().size(); i++)
        {
            if(novoPitanje.getOdgovori().get(i).equals(novoPitanje.getTacan()))
                return i;
        }

        return -1;
    }

    @Override
    public void onDestroy()
    {
        super.onDestroy();
    }

    @Override
    public void onReceiveResult(int resultCode, Bundle resultData)
    {
        Log.d("RESULT CODE", String.valueOf(resultCode));
        switch (resultCode)
        {
            case intsDodajPitanjeUBazu.STATUS_RUNNING:
                /* Ovdje ide kod koji obavještava korisnika da je poziv upućen */
                break;
            case intsDodajPitanjeUBazu.STATUS_FINISHED:

                /* Dohvatanje rezultata i update UI */
                //AKO SE VRATI NESTO, ZNACI DA JE DOBRO OBALJENO DODAVANJE U BAZU
                if(resultData.getString("zadatak") != null &&
                        resultData.get("zadatak").equals("dobavljeno sve iz baze"))
                {
                    alSveKategorije.clear();
                    alSveKategorije.addAll((ArrayList<Kategorija>) resultData.getSerializable("alSveKategorije"));

                    alSviKvizovi.clear();
                    alSviKvizovi.addAll((ArrayList<Kviz>) resultData.getSerializable("alSviKvizovi"));

                    alSvaPitanja.clear();
                    alSvaPitanja.addAll((ArrayList<Pitanje>) resultData.getSerializable("alSvaPitanja"));
                }
                else if (resultData.getString("zadatak") != null &&
                        resultData.get("zadatak").equals("dodano pitanje"))
                {
                    Intent mojIntent = new Intent(DodajPitanjeAkt.this, DodajKvizAkt.class);

                    alSvaPitanja.add(novoPitanje);

                    ArrayList<Pitanje> alMogucaPitanja = (ArrayList<Pitanje>)getIntent().getSerializableExtra("trenutnoStanjeAlMogucaPitanja");
                    String etNaziv =(String) getIntent().getStringExtra("trenutnoStanjeEtNaziv");
                    String spKategorije = (String) getIntent().getStringExtra("trenutnoStanjeSpKategorije");
                    alSveKategorije = (ArrayList<Kategorija>) getIntent().getSerializableExtra("sveKategorije");
                    alSviKvizovi = (ArrayList<Kviz>) getIntent().getSerializableExtra("sviKvizovi");

                    alPitanjaUKvizu.add(novoPitanje);
                    mojIntent.putExtra("alDodanaPitanjaVrati", alPitanjaUKvizu);
                    mojIntent.putExtra("alMogucaPitanjaVrati", alMogucaPitanja);
                    mojIntent.putExtra("etNazivVrati", etNaziv);
                    mojIntent.putExtra("spKategorijeVrati", spKategorije);

                    mojIntent.putExtra("kljucSvaPitanja", alSvaPitanja);
                    mojIntent.putExtra("kljucArraySveKategorije", alSveKategorije);
                    mojIntent.putExtra("kljucArraySviKvizovi", alSviKvizovi);

                    mojIntent.putExtra("dodavanjePitanja", "dodavanjePitanja");

                    mojIntent.putExtra("nacinRada", getIntent().getStringExtra("nacinRada"));

                    if(getIntent().getStringExtra("nacinRada").equals("editovanjeKviza"))
                    {
                        mojIntent.putExtra("odabraniKviz", getIntent().getSerializableExtra("odabraniKviz"));
                        mojIntent.putExtra("pozicijaKvizaKojiSeMijenja", getIntent().getIntExtra("pozicijaKvizaKojiSeMijenja", 0));
                    }

                    DodajPitanjeAkt.this.startActivity(mojIntent);
                }

                break;
            case intsDodajPitanjeUBazu.STATUS_ERROR:
                /* Slučaj kada je došlo do greške */

                if (resultData.getString("zadatak") != null &&
                    resultData.get("zadatak").equals("vec postoji pitanje"))
                {
                    //AKO SE VRATI DA JE NEUSPJESNO DODJENO DO OVJDE, TJ. DA NIJE UNESENA KATEGORIJA, ISPISI ALERT DIALOG
                    AlertDialog alertDialog = new AlertDialog.Builder(this).create();
                    alertDialog.setTitle("PITANJE VEC POSOTJI U BAZI");
                    alertDialog.setMessage("Uneseno pitanje već postoji!");
                    alertDialog.setButton(android.app.AlertDialog.BUTTON_NEUTRAL, "OK",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which)
                                {
                                    dialog.dismiss();
                                    napuniAtributeNaOsnovuStanjaUBazi();
                                }
                            });
                    alertDialog.show();
                }
                else if(resultData.getString("zadatak") != null &&
                        resultData.get("zadatak").equals("nema kolekcije neke u bazi"))
                {
                    if(resultData.getSerializable("alSveKategorije") != null)
                    {
                        alSveKategorije.clear();
                        alSveKategorije.addAll((ArrayList<Kategorija>) resultData.getSerializable("alSveKategorije"));
                    }

                    if(resultData.getSerializable("alSviKvizovi") != null)
                    {
                        alSviKvizovi.clear();
                        alSviKvizovi.addAll((ArrayList<Kviz>) resultData.getSerializable("alSviKvizovi"));
                    }

                    if(resultData.getSerializable("alSvaPitanja") != null)
                    {
                        alSvaPitanja.clear();
                        alSvaPitanja.addAll((ArrayList<Pitanje>) resultData.getSerializable("alSvaPitanja"));
                    }
                }

                break;
        }
    }

    private void napuniAtributeNaOsnovuStanjaUBazi()
    {
        Intent mojIntent = new Intent(Intent.ACTION_SYNC, null, this, intsDajSveKategorijeSveKvizoveSvaPitanja.class);
        resultReceiverZaSveIntentServise risiver = new resultReceiverZaSveIntentServise(new Handler());
        risiver.setReceiver(this);
        mojIntent.putExtra("risiver", risiver);
        startService(mojIntent);
    }
}
