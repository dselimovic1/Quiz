package ba.unsa.etf.rma.adapteri;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Pitanje;

public class AdapterListaPitanja extends BaseAdapter
{
    /*********** Declare Used Variables *********/
    private Activity activity;
    private ArrayList data;
    private static LayoutInflater inflater = null;
    public Resources res;

    Pitanje pitanje = null;
    int i=0;

    /*************  CustomAdapter Constructor *****************/
    public AdapterListaPitanja(Activity a, ArrayList d, Resources resLocal)
    {
        /********** Take passed values **********/
        activity = a;
        data = d;
        res = resLocal;

        /***********  Layout inflator to call external xml layout () ***********/
        inflater = ( LayoutInflater )activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    /******** What is the size of Passed Arraylist Size ************/
    public int getCount()
    {
        if(data.size()<=0)
            return 0;

        return data.size();
    }

    public Object getItem(int position)
    {
        return position;
    }

    public long getItemId(int position)
    {
        return position;
    }

    /********* Create a holder Class to contain inflated xml file elements *********/
    public static class ViewHolder
    {
        public TextView clanListe;
    }

    /****** Depends upon data size called for each row , Create each ListView row *****/
    public View getView(int position, View convertView, ViewGroup parent)
    {
        View vi = convertView;
        AdapterListaPitanja.ViewHolder holder;

        if(convertView == null)
        {

            /****** Inflate tabitem.xml file for each row ( Defined below ) *******/
            vi = inflater.inflate(R.layout.adapter_lista_pitanja, null);

            /****** View Holder Object to contain tabitem.xml file elements ******/

            holder = new AdapterListaPitanja.ViewHolder();
            holder.clanListe = (TextView) vi.findViewById(R.id.nazivPitanja);

            /************  Set holder with LayoutInflater ************/
            vi.setTag( holder );
        }
        else
            holder=(AdapterListaPitanja.ViewHolder) vi.getTag();

        if(data.size()<=0)
        {
            holder.clanListe.setText("Nema dostpunih podataka");
        }
        else
        {
            /***** Get each Model object from Arraylist ********/
            pitanje = null;
            pitanje = ( Pitanje ) data.get( position );


            /************  Set Model values in Holder elements ***********/
            holder.clanListe.setText( pitanje.getNaziv() );

            /******** Set Item Click Listner for LayoutInflater for each row *******/
            //vi.setOnClickListener(new OnItemClickListener( position ));
        }
        return vi;
    }

}

