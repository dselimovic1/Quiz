package ba.unsa.etf.rma.asyncTaskovi;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

import ba.unsa.etf.rma.R;

//DODTI U "Manifest" PERMISSION
public class asytTestna extends AsyncTask<String, Integer, Void>
{
    //ATRIBUTI
    String token;
    private OnTokenSearchDone pozivatelj;

    Context kontekst;

    //INTERFEJS
    public interface OnTokenSearchDone
    {
        public void onDone(String rezultatToken);
    }

    //KONSTRUKTOR
    public asytTestna(OnTokenSearchDone p, Context context)
    {
        //"pozivatelj" se koristi kao referenca na objekat koji je koristen za kreiranje objekta tipa "PretragaMuzicar"
        pozivatelj = p;

        kontekst = context;
    }

    //METODE
    @Override
    protected Void doInBackground(String... params)
    {
        try
        {
            InputStream is = kontekst.getResources().openRawResource(R.raw.secret);
            GoogleCredential credentials = GoogleCredential.fromStream(is).
                    createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();

            this.token = credentials.getAccessToken();

            Log.d("TOKEN", token);

            //String url = "https://firestore.googleapis.com/v1/projects/spirala2019nedzad/databases/(default)/documents/Kvizovi?access_token=";
            String url = "https://firestore.googleapis.com/v1/projects/spirala2019nedzad/databases/(default)/documents/Kvizovi?documentId=imeDokumenta";

            URL urlObjekat = new URL(url);

            HttpURLConnection konekcija = (HttpURLConnection) urlObjekat.openConnection();

            konekcija.setRequestProperty("Authorization", "Bearer "+token);

            //govori koju akciju vrsimo
            konekcija.setRequestMethod("POST");
            //govori u kojem formatu upisujemo u bazu
            konekcija.setRequestProperty("Content-Type", "appliction/json");
            //namjesta da se: prihvati response i format u kojem se prihvata
            konekcija.setRequestProperty("Accept", "appliation/json");

            String dokuemnt = "{ \"fields\": { \"atribut\": {\"stringValue\":\"novi dokument\"}}}";

            OutputStream outputStream = konekcija.getOutputStream();
            byte[] unos = dokuemnt.getBytes();
            outputStream.write(unos, 0, unos.length);

            int code = konekcija.getResponseCode();
            InputStream odgovor = konekcija.getInputStream();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(odgovor, "utf-8"));
            StringBuilder response = new StringBuilder();
            String responseLine = null;
            while((responseLine = bufferedReader.readLine()) != null)
                response.append(responseLine.trim());

            Log.d("ODGOVOR", response.toString());

            //-----------------------------------------------
            String url2 = "https://firestore.googleapis.com/v1/projects/spirala2019nedzad/databases/(default)/documents/Kvizovi?access_token=";
            URL urlObjekat2 = new URL(url2+ URLEncoder.encode(token, "UTF-8"));

            HttpURLConnection konekcija2 = (HttpURLConnection) urlObjekat2.openConnection();

            //govori koju akciju vrsimo
            konekcija2.setRequestMethod("GET");
            //ovaj property mora biti podesen da bi mogao koristiti JSON format za slatnje zahtjeva
            konekcija2.setRequestProperty("Content-Type", "appliction/json");
            //namjesta da se: prihvati response i format u kojem se prihvata
            konekcija2.setRequestProperty("Accept", "appliation/json");

            int code2 = konekcija2.getResponseCode();
            InputStream odgovor2 = konekcija2.getInputStream();
            BufferedReader bufferedReader2 = new BufferedReader(new InputStreamReader(odgovor2, "utf-8"));
            StringBuilder response2 = new StringBuilder();
            String responseLine2 = null;
            while((responseLine2 = bufferedReader2.readLine()) != null)
                response2.append(responseLine2 +"\n");

            Log.d("ODGOVOR2", response2.toString());

        }
        catch (IOException e)
        {
            e.printStackTrace();
        }

        return null;
    }

    //metoda prekolopljenog interfejsa
    protected void onPostExecute(Void aVoid)
    {
        super.onPostExecute(aVoid);

        pozivatelj.onDone(token);
    }
}

