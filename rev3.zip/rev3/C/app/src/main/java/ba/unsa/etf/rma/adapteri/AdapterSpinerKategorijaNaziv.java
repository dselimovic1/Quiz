package ba.unsa.etf.rma.adapteri;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kategorija;

public class AdapterSpinerKategorijaNaziv extends ArrayAdapter<Kategorija>
{
    private Context context;
    private ArrayList<Kategorija> listaKategorija;

    private Kategorija prviElement;
    private boolean prviPut;

    public AdapterSpinerKategorijaNaziv(Context context, int textViewResourceId, ArrayList<Kategorija> values, String defaultniText)
    {
        super(context, textViewResourceId, values);

        this.context = context;
        this.listaKategorija = values;
    }


    public int getCount(){
        return listaKategorija.size();
    }

    public Kategorija getItem(int position){
        return listaKategorija.get(position);
    }

    public long getItemId(int position){
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent)
    {
        TextView view = new TextView(context);
        view.setText(listaKategorija.get(position).getNaziv());

        return view;
    }

    //View of Spinner on dropdown Popping
    @Override
    public View getDropDownView(int position, View convertView, ViewGroup parent)
    {

        TextView view = new TextView(context);
        view.setText(listaKategorija.get(position).getNaziv());
        return view;
    }
}
