package ba.unsa.etf.rma.adapteri;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;

public class AdapterListaOdgovra extends ArrayAdapter<String>
{
    private Context context;
    private ArrayList<String> odgovori;

    public AdapterListaOdgovra(Context context, int textViewResourceId, ArrayList<String> values)
    {
        super(context, textViewResourceId, values);

        this.context = context;
        this.odgovori = values;
    }

    public int getCount(){
        return odgovori.size();
    }

    public String getItem(int position){
        return odgovori.get(position);
    }

    public long getItemId(int position){
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent)
    {
        //View v = super.getView(position, convertView, parent);

        if(convertView == null)
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.adapter_lista_pitanja, parent, false);

        //v.setBackgroundColor(Color.parseColor("#8BC34A"));

        final String odgovor = getItem(position);

        TextView textView = (TextView) convertView.findViewById(R.id.nazivPitanja);
        textView.setText(odgovor);

        return convertView;
    }

}

