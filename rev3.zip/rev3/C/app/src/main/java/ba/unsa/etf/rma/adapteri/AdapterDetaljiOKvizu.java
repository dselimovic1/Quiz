package ba.unsa.etf.rma.adapteri;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.maltaisn.icondialog.IconHelper;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kviz;

public class AdapterDetaljiOKvizu extends ArrayAdapter<Kviz>
{
    private Context context;
    private ArrayList<Kviz> listaKvizova;

    public AdapterDetaljiOKvizu(Context context, int textViewResourceId, ArrayList<Kviz> values)
    {
        super(context, textViewResourceId, values);

        this.context = context;
        this.listaKvizova= values;
    }

    public int getCount(){
        return listaKvizova.size();
    }

    public Kviz getItem(int position){
        return listaKvizova.get(position);
    }

    public long getItemId(int position){
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent)
    {
        final Kviz kviz = getItem(position);

        if(convertView == null)
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.adapter_detali_frag, parent, false);

        TextView tvNazivKviza = (TextView) convertView.findViewById(R.id.nazivKviza);
        tvNazivKviza.setText(kviz.getNaziv());

        TextView ukupanBrojPitanjaUKvizu = (TextView) convertView.findViewById(R.id.ukupanBrojPitanjaUKvizu);
        if(kviz.getNaziv().equals("Dodaj kviz") == false)
        ukupanBrojPitanjaUKvizu.setText(String.valueOf(kviz.getPitanja().size()));
        else
            ukupanBrojPitanjaUKvizu.setText("");


        final ImageView imageView = (ImageView) convertView.findViewById(R.id.ikonaKviza);

        final IconHelper iconHelper = IconHelper.getInstance(convertView.getContext());
        iconHelper.addLoadCallback(new IconHelper.LoadCallback() {

            @Override
            public void onDataLoaded()
            {
                imageView.setImageDrawable(iconHelper.getIcon(Integer.parseInt(kviz.getKategorija().getId())).getDrawable(getContext()));
            }
        });

        return convertView;
    }

}
